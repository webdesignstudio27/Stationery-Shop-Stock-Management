﻿namespace STATIONERY_SHOP
{
    partial class Customer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Customer));
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            pictureBox8 = new PictureBox();
            pictureBox7 = new PictureBox();
            pictureBox6 = new PictureBox();
            pictureBox5 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox2 = new PictureBox();
            label1 = new Label();
            pictureBox9 = new PictureBox();
            pictureBox1 = new PictureBox();
            pictureBox3 = new PictureBox();
            panel1 = new Panel();
            BillPrint = new Button();
            printPreviewControl1 = new PrintPreviewControl();
            GrdTotalLbl = new Label();
            ClearImg = new PictureBox();
            ViewBtn = new Button();
            Date = new Label();
            label6 = new Label();
            SartDate = new DateTimePicker();
            RefreshImg = new PictureBox();
            SearchImg = new PictureBox();
            SearchTb = new TextBox();
            SalesDGV = new DataGridView();
            printDocument1 = new System.Drawing.Printing.PrintDocument();
            pictureBox10 = new PictureBox();
            pictureBox11 = new PictureBox();
            printPreviewDialog1 = new PrintPreviewDialog();
            printDialog1 = new PrintDialog();
            saveFileDialog1 = new SaveFileDialog();
            pictureBox12 = new PictureBox();
            pictureBox13 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)ClearImg).BeginInit();
            ((System.ComponentModel.ISupportInitialize)RefreshImg).BeginInit();
            ((System.ComponentModel.ISupportInitialize)SearchImg).BeginInit();
            ((System.ComponentModel.ISupportInitialize)SalesDGV).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).BeginInit();
            SuspendLayout();
            // 
            // pictureBox8
            // 
            pictureBox8.Image = (Image)resources.GetObject("pictureBox8.Image");
            pictureBox8.Location = new Point(1, 884);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(53, 58);
            pictureBox8.TabIndex = 21;
            pictureBox8.TabStop = false;
            pictureBox8.Click += pictureBox8_Click;
            // 
            // pictureBox7
            // 
            pictureBox7.Image = (Image)resources.GetObject("pictureBox7.Image");
            pictureBox7.Location = new Point(3, 540);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(53, 58);
            pictureBox7.TabIndex = 22;
            pictureBox7.TabStop = false;
            pictureBox7.Click += pictureBox7_Click;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = (Image)resources.GetObject("pictureBox6.Image");
            pictureBox6.Location = new Point(3, 446);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(53, 58);
            pictureBox6.TabIndex = 23;
            pictureBox6.TabStop = false;
            pictureBox6.Click += pictureBox6_Click;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(2, 354);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(53, 58);
            pictureBox5.TabIndex = 24;
            pictureBox5.TabStop = false;
            pictureBox5.Click += pictureBox5_Click;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(1, 263);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(53, 58);
            pictureBox4.TabIndex = 25;
            pictureBox4.TabStop = false;
            pictureBox4.Click += pictureBox4_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(1, 12);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(53, 58);
            pictureBox2.TabIndex = 20;
            pictureBox2.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial Rounded MT Bold", 22.2F, FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Red;
            label1.Location = new Point(136, 74);
            label1.Name = "label1";
            label1.Size = new Size(345, 43);
            label1.TabIndex = 3;
            label1.Text = "Manage Customer";
            label1.Click += label1_Click;
            // 
            // pictureBox9
            // 
            pictureBox9.Image = (Image)resources.GetObject("pictureBox9.Image");
            pictureBox9.Location = new Point(1754, 23);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(53, 58);
            pictureBox9.TabIndex = 2;
            pictureBox9.TabStop = false;
            pictureBox9.Click += pictureBox9_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(57, 40);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(73, 77);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(1, 163);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(53, 58);
            pictureBox3.TabIndex = 26;
            pictureBox3.TabStop = false;
            pictureBox3.Click += pictureBox3_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.Controls.Add(pictureBox13);
            panel1.Controls.Add(pictureBox12);
            panel1.Controls.Add(BillPrint);
            panel1.Controls.Add(printPreviewControl1);
            panel1.Controls.Add(GrdTotalLbl);
            panel1.Controls.Add(ClearImg);
            panel1.Controls.Add(ViewBtn);
            panel1.Controls.Add(Date);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(SartDate);
            panel1.Controls.Add(RefreshImg);
            panel1.Controls.Add(SearchImg);
            panel1.Controls.Add(SearchTb);
            panel1.Controls.Add(SalesDGV);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(pictureBox9);
            panel1.Controls.Add(pictureBox1);
            panel1.Dock = DockStyle.Right;
            panel1.Location = new Point(62, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1839, 983);
            panel1.TabIndex = 19;
            // 
            // BillPrint
            // 
            BillPrint.BackColor = Color.DodgerBlue;
            BillPrint.Font = new Font("Arial Unicode MS", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            BillPrint.ForeColor = Color.White;
            BillPrint.Location = new Point(1399, 842);
            BillPrint.Name = "BillPrint";
            BillPrint.Size = new Size(258, 58);
            BillPrint.TabIndex = 72;
            BillPrint.Text = "Download";
            BillPrint.UseVisualStyleBackColor = false;
            BillPrint.Click += BillPrint_Click;
            // 
            // printPreviewControl1
            // 
            printPreviewControl1.AutoZoom = false;
            printPreviewControl1.BackColor = Color.White;
            printPreviewControl1.Enabled = false;
            printPreviewControl1.Location = new Point(1074, 74);
            printPreviewControl1.Name = "printPreviewControl1";
            printPreviewControl1.Size = new Size(733, 729);
            printPreviewControl1.TabIndex = 60;
            printPreviewControl1.Zoom = 0.5D;
            printPreviewControl1.Click += printPreviewControl1_Click;
            // 
            // GrdTotalLbl
            // 
            GrdTotalLbl.AutoSize = true;
            GrdTotalLbl.Font = new Font("Arial Unicode MS", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            GrdTotalLbl.ForeColor = Color.FromArgb(0, 192, 0);
            GrdTotalLbl.Location = new Point(48, 311);
            GrdTotalLbl.Name = "GrdTotalLbl";
            GrdTotalLbl.Size = new Size(26, 40);
            GrdTotalLbl.TabIndex = 71;
            GrdTotalLbl.Text = " ";
            GrdTotalLbl.Click += GrdTotalLbl_Click;
            // 
            // ClearImg
            // 
            ClearImg.Image = (Image)resources.GetObject("ClearImg.Image");
            ClearImg.Location = new Point(637, 172);
            ClearImg.Name = "ClearImg";
            ClearImg.Size = new Size(57, 52);
            ClearImg.TabIndex = 70;
            ClearImg.TabStop = false;
            ClearImg.Click += ClearImg_Click;
            // 
            // ViewBtn
            // 
            ViewBtn.BackColor = Color.Red;
            ViewBtn.Font = new Font("Arial Unicode MS", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            ViewBtn.ForeColor = Color.White;
            ViewBtn.Location = new Point(38, 236);
            ViewBtn.Name = "ViewBtn";
            ViewBtn.Size = new Size(266, 58);
            ViewBtn.TabIndex = 69;
            ViewBtn.Text = "View Details";
            ViewBtn.UseVisualStyleBackColor = false;
            ViewBtn.Click += ViewBtn_Click;
            // 
            // Date
            // 
            Date.AutoSize = true;
            Date.Font = new Font("Arial Unicode MS", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            Date.ForeColor = Color.Purple;
            Date.Location = new Point(323, 142);
            Date.Name = "Date";
            Date.Size = new Size(85, 40);
            Date.TabIndex = 68;
            Date.Text = "Date";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Arial Unicode MS", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.Purple;
            label6.Location = new Point(76, 142);
            label6.Name = "label6";
            label6.Size = new Size(185, 40);
            label6.TabIndex = 67;
            label6.Text = "Bill Number";
            // 
            // SartDate
            // 
            SartDate.CalendarFont = new Font("Arial Narrow", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            SartDate.CalendarForeColor = Color.Red;
            SartDate.CalendarMonthBackground = Color.FromArgb(255, 192, 192);
            SartDate.CalendarTitleBackColor = Color.FromArgb(255, 128, 128);
            SartDate.CalendarTitleForeColor = Color.Red;
            SartDate.CalendarTrailingForeColor = Color.Red;
            SartDate.Font = new Font("Arial Narrow", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            SartDate.Location = new Point(301, 191);
            SartDate.Name = "SartDate";
            SartDate.RightToLeft = RightToLeft.Yes;
            SartDate.RightToLeftLayout = true;
            SartDate.Size = new Size(195, 30);
            SartDate.TabIndex = 66;
            SartDate.ValueChanged += SartDate_ValueChanged;
            // 
            // RefreshImg
            // 
            RefreshImg.Image = (Image)resources.GetObject("RefreshImg.Image");
            RefreshImg.Location = new Point(574, 172);
            RefreshImg.Name = "RefreshImg";
            RefreshImg.Size = new Size(57, 52);
            RefreshImg.TabIndex = 65;
            RefreshImg.TabStop = false;
            RefreshImg.Click += RefreshImg_Click;
            // 
            // SearchImg
            // 
            SearchImg.Image = (Image)resources.GetObject("SearchImg.Image");
            SearchImg.Location = new Point(511, 172);
            SearchImg.Name = "SearchImg";
            SearchImg.Size = new Size(57, 52);
            SearchImg.TabIndex = 64;
            SearchImg.TabStop = false;
            SearchImg.Click += SearchImg_Click_1;
            // 
            // SearchTb
            // 
            SearchTb.Font = new Font("Arial Unicode MS", 13.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            SearchTb.ForeColor = Color.Red;
            SearchTb.Location = new Point(38, 185);
            SearchTb.Multiline = true;
            SearchTb.Name = "SearchTb";
            SearchTb.PlaceholderText = "Search Bill Number";
            SearchTb.Size = new Size(245, 39);
            SearchTb.TabIndex = 63;
            // 
            // SalesDGV
            // 
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = Color.FromArgb(255, 192, 192);
            dataGridViewCellStyle1.Font = new Font("Arial", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            dataGridViewCellStyle1.ForeColor = Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = Color.Red;
            dataGridViewCellStyle1.SelectionForeColor = Color.White;
            SalesDGV.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            SalesDGV.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            SalesDGV.BackgroundColor = Color.White;
            SalesDGV.BorderStyle = BorderStyle.None;
            SalesDGV.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = Color.Red;
            dataGridViewCellStyle2.Font = new Font("Arial", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            dataGridViewCellStyle2.ForeColor = Color.White;
            dataGridViewCellStyle2.SelectionBackColor = Color.Red;
            dataGridViewCellStyle2.SelectionForeColor = Color.White;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            SalesDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            SalesDGV.ColumnHeadersHeight = 45;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = Color.FromArgb(255, 128, 128);
            dataGridViewCellStyle3.Font = new Font("Arial", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            dataGridViewCellStyle3.ForeColor = Color.Red;
            dataGridViewCellStyle3.SelectionBackColor = Color.Red;
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            SalesDGV.DefaultCellStyle = dataGridViewCellStyle3;
            SalesDGV.GridColor = Color.Red;
            SalesDGV.ImeMode = ImeMode.On;
            SalesDGV.Location = new Point(8, 363);
            SalesDGV.Name = "SalesDGV";
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = Color.FromArgb(255, 128, 128);
            dataGridViewCellStyle4.Font = new Font("Arial Narrow", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            dataGridViewCellStyle4.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = Color.Red;
            dataGridViewCellStyle4.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = DataGridViewTriState.True;
            SalesDGV.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            SalesDGV.RowHeadersWidth = 70;
            SalesDGV.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            SalesDGV.Size = new Size(1028, 617);
            SalesDGV.TabIndex = 51;
            SalesDGV.CellContentClick += SalesDGV_CellContentClick;
            // 
            // printDocument1
            // 
            printDocument1.PrintPage += printDocument1_PrintPage_1;
            // 
            // pictureBox10
            // 
            pictureBox10.Image = (Image)resources.GetObject("pictureBox10.Image");
            pictureBox10.Location = new Point(1, 647);
            pictureBox10.Name = "pictureBox10";
            pictureBox10.Size = new Size(62, 64);
            pictureBox10.TabIndex = 58;
            pictureBox10.TabStop = false;
            pictureBox10.Click += pictureBox10_Click;
            // 
            // pictureBox11
            // 
            pictureBox11.Image = (Image)resources.GetObject("pictureBox11.Image");
            pictureBox11.Location = new Point(2, 739);
            pictureBox11.Name = "pictureBox11";
            pictureBox11.Size = new Size(62, 64);
            pictureBox11.TabIndex = 59;
            pictureBox11.TabStop = false;
            pictureBox11.Click += pictureBox11_Click;
            // 
            // printPreviewDialog1
            // 
            printPreviewDialog1.AutoScrollMargin = new Size(0, 0);
            printPreviewDialog1.AutoScrollMinSize = new Size(0, 0);
            printPreviewDialog1.ClientSize = new Size(400, 300);
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.Enabled = true;
            printPreviewDialog1.Icon = (Icon)resources.GetObject("printPreviewDialog1.Icon");
            printPreviewDialog1.Name = "printPreviewDialog1";
            printPreviewDialog1.Visible = false;
            printPreviewDialog1.Load += printPreviewDialog1_Load;
            // 
            // printDialog1
            // 
            printDialog1.UseEXDialog = true;
            // 
            // saveFileDialog1
            // 
            saveFileDialog1.FileOk += saveFileDialog1_FileOk;
            // 
            // pictureBox12
            // 
            pictureBox12.BackColor = Color.Red;
            pictureBox12.Image = (Image)resources.GetObject("pictureBox12.Image");
            pictureBox12.Location = new Point(48, 248);
            pictureBox12.Name = "pictureBox12";
            pictureBox12.Size = new Size(36, 35);
            pictureBox12.TabIndex = 73;
            pictureBox12.TabStop = false;
            // 
            // pictureBox13
            // 
            pictureBox13.BackColor = Color.DodgerBlue;
            pictureBox13.Image = (Image)resources.GetObject("pictureBox13.Image");
            pictureBox13.Location = new Point(1606, 854);
            pictureBox13.Name = "pictureBox13";
            pictureBox13.Size = new Size(36, 35);
            pictureBox13.TabIndex = 74;
            pictureBox13.TabStop = false;
            // 
            // Customer
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(0, 192, 0);
            ClientSize = new Size(1901, 983);
            Controls.Add(pictureBox11);
            Controls.Add(pictureBox10);
            Controls.Add(pictureBox8);
            Controls.Add(pictureBox7);
            Controls.Add(pictureBox6);
            Controls.Add(pictureBox5);
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox3);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Customer";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Sold";
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)ClearImg).EndInit();
            ((System.ComponentModel.ISupportInitialize)RefreshImg).EndInit();
            ((System.ComponentModel.ISupportInitialize)SearchImg).EndInit();
            ((System.ComponentModel.ISupportInitialize)SalesDGV).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private PictureBox pictureBox8;
        private PictureBox pictureBox7;
        private PictureBox pictureBox6;
        private PictureBox pictureBox5;
        private PictureBox pictureBox4;
        private PictureBox pictureBox2;
        private Label label1;
        private PictureBox pictureBox9;
        private PictureBox pictureBox1;
        private PictureBox pictureBox3;
        private Panel panel1;
        private DataGridView SalesDGV;
        private PictureBox pictureBox10;
        private PictureBox pictureBox11;
        private Label Date;
        private Label label6;
        private DateTimePicker SartDate;
        private PictureBox RefreshImg;
        private PictureBox SearchImg;
        private TextBox SearchTb;
        private Button ViewBtn;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private PictureBox ClearImg;
        private Label GrdTotalLbl;
        private PrintPreviewControl printPreviewControl1;
        private PrintPreviewDialog printPreviewDialog1;
        private PrintDialog printDialog1;
        private SaveFileDialog saveFileDialog1;
        private Button BillPrint;
        private PictureBox pictureBox13;
        private PictureBox pictureBox12;
    }
}