﻿namespace STATIONERY_SHOP
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Dashboard));
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle6 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle7 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle8 = new DataGridViewCellStyle();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            panel1 = new Panel();
            pictureBox12 = new PictureBox();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            EndDate = new DateTimePicker();
            SartDate = new DateTimePicker();
            SalaryDGV = new DataGridView();
            RefreshImg = new PictureBox();
            SearchImg = new PictureBox();
            SearchTb = new TextBox();
            SalesDGV = new DataGridView();
            pictureBox13 = new PictureBox();
            Chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            label3 = new Label();
            panel3 = new Panel();
            pictureBox11 = new PictureBox();
            SalesLbl = new Label();
            label5 = new Label();
            panel2 = new Panel();
            StockLbl = new Label();
            pictureBox10 = new PictureBox();
            label4 = new Label();
            label2 = new Label();
            label1 = new Label();
            pictureBox9 = new PictureBox();
            pictureBox1 = new PictureBox();
            pictureBox8 = new PictureBox();
            pictureBox7 = new PictureBox();
            pictureBox6 = new PictureBox();
            pictureBox5 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox2 = new PictureBox();
            pictureBox14 = new PictureBox();
            pictureBox15 = new PictureBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).BeginInit();
            ((System.ComponentModel.ISupportInitialize)SalaryDGV).BeginInit();
            ((System.ComponentModel.ISupportInitialize)RefreshImg).BeginInit();
            ((System.ComponentModel.ISupportInitialize)SearchImg).BeginInit();
            ((System.ComponentModel.ISupportInitialize)SalesDGV).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).BeginInit();
            ((System.ComponentModel.ISupportInitialize)Chart1).BeginInit();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox14).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox15).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.Controls.Add(pictureBox12);
            panel1.Controls.Add(label9);
            panel1.Controls.Add(label8);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(EndDate);
            panel1.Controls.Add(SartDate);
            panel1.Controls.Add(SalaryDGV);
            panel1.Controls.Add(RefreshImg);
            panel1.Controls.Add(SearchImg);
            panel1.Controls.Add(SearchTb);
            panel1.Controls.Add(SalesDGV);
            panel1.Controls.Add(pictureBox13);
            panel1.Controls.Add(Chart1);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(panel3);
            panel1.Controls.Add(panel2);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(pictureBox9);
            panel1.Controls.Add(pictureBox1);
            panel1.Dock = DockStyle.Right;
            panel1.Location = new Point(62, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1839, 983);
            panel1.TabIndex = 11;
            panel1.Paint += panel1_Paint;
            // 
            // pictureBox12
            // 
            pictureBox12.Image = (Image)resources.GetObject("pictureBox12.Image");
            pictureBox12.Location = new Point(1220, 105);
            pictureBox12.Name = "pictureBox12";
            pictureBox12.Size = new Size(56, 52);
            pictureBox12.TabIndex = 65;
            pictureBox12.TabStop = false;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Arial Rounded MT Bold", 24F, FontStyle.Italic, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.FromArgb(255, 128, 0);
            label9.Location = new Point(1273, 105);
            label9.Name = "label9";
            label9.Size = new Size(143, 46);
            label9.TabIndex = 64;
            label9.Text = "Bonus";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Arial Unicode MS", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.Purple;
            label8.Location = new Point(493, 412);
            label8.Name = "label8";
            label8.Size = new Size(151, 40);
            label8.TabIndex = 63;
            label8.Text = "End Date";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Arial Unicode MS", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.Purple;
            label7.Location = new Point(296, 412);
            label7.Name = "label7";
            label7.Size = new Size(162, 40);
            label7.TabIndex = 62;
            label7.Text = "Start Date";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Arial Unicode MS", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.Purple;
            label6.Location = new Point(52, 412);
            label6.Name = "label6";
            label6.Size = new Size(175, 40);
            label6.TabIndex = 61;
            label6.Text = "Sales User";
            // 
            // EndDate
            // 
            EndDate.CalendarFont = new Font("Arial Narrow", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            EndDate.CalendarForeColor = Color.Red;
            EndDate.CalendarMonthBackground = Color.FromArgb(255, 192, 192);
            EndDate.CalendarTitleBackColor = Color.FromArgb(255, 128, 128);
            EndDate.CalendarTitleForeColor = Color.Red;
            EndDate.CalendarTrailingForeColor = Color.Red;
            EndDate.Font = new Font("Arial Narrow", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            EndDate.Location = new Point(484, 465);
            EndDate.Name = "EndDate";
            EndDate.RightToLeft = RightToLeft.Yes;
            EndDate.RightToLeftLayout = true;
            EndDate.Size = new Size(203, 30);
            EndDate.TabIndex = 60;
            // 
            // SartDate
            // 
            SartDate.CalendarFont = new Font("Arial Narrow", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            SartDate.CalendarForeColor = Color.Red;
            SartDate.CalendarMonthBackground = Color.FromArgb(255, 192, 192);
            SartDate.CalendarTitleBackColor = Color.FromArgb(255, 128, 128);
            SartDate.CalendarTitleForeColor = Color.Red;
            SartDate.CalendarTrailingForeColor = Color.Red;
            SartDate.Font = new Font("Arial Narrow", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            SartDate.Location = new Point(274, 465);
            SartDate.Name = "SartDate";
            SartDate.RightToLeft = RightToLeft.Yes;
            SartDate.RightToLeftLayout = true;
            SartDate.Size = new Size(195, 30);
            SartDate.TabIndex = 59;
            // 
            // SalaryDGV
            // 
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = Color.FromArgb(255, 192, 192);
            dataGridViewCellStyle1.Font = new Font("Arial", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            dataGridViewCellStyle1.ForeColor = Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = Color.Red;
            dataGridViewCellStyle1.SelectionForeColor = Color.White;
            SalaryDGV.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            SalaryDGV.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            SalaryDGV.BackgroundColor = Color.White;
            SalaryDGV.BorderStyle = BorderStyle.None;
            SalaryDGV.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = Color.Red;
            dataGridViewCellStyle2.Font = new Font("Arial", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            dataGridViewCellStyle2.ForeColor = Color.White;
            dataGridViewCellStyle2.SelectionBackColor = Color.Red;
            dataGridViewCellStyle2.SelectionForeColor = Color.White;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            SalaryDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            SalaryDGV.ColumnHeadersHeight = 45;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = Color.FromArgb(255, 128, 128);
            dataGridViewCellStyle3.Font = new Font("Arial", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            dataGridViewCellStyle3.ForeColor = Color.Red;
            dataGridViewCellStyle3.SelectionBackColor = Color.Red;
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            SalaryDGV.DefaultCellStyle = dataGridViewCellStyle3;
            SalaryDGV.GridColor = Color.Red;
            SalaryDGV.ImeMode = ImeMode.On;
            SalaryDGV.Location = new Point(916, 163);
            SalaryDGV.Name = "SalaryDGV";
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = Color.FromArgb(255, 128, 128);
            dataGridViewCellStyle4.Font = new Font("Arial Narrow", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            dataGridViewCellStyle4.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = Color.Red;
            dataGridViewCellStyle4.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = DataGridViewTriState.True;
            SalaryDGV.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            SalaryDGV.RowHeadersWidth = 70;
            SalaryDGV.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            SalaryDGV.Size = new Size(825, 219);
            SalaryDGV.TabIndex = 58;
            // 
            // RefreshImg
            // 
            RefreshImg.Image = (Image)resources.GetObject("RefreshImg.Image");
            RefreshImg.Location = new Point(756, 446);
            RefreshImg.Name = "RefreshImg";
            RefreshImg.Size = new Size(57, 52);
            RefreshImg.TabIndex = 57;
            RefreshImg.TabStop = false;
            RefreshImg.Click += RefreshImg_Click;
            // 
            // SearchImg
            // 
            SearchImg.Image = (Image)resources.GetObject("SearchImg.Image");
            SearchImg.Location = new Point(693, 446);
            SearchImg.Name = "SearchImg";
            SearchImg.Size = new Size(57, 52);
            SearchImg.TabIndex = 56;
            SearchImg.TabStop = false;
            SearchImg.Click += SearchImg_Click;
            // 
            // SearchTb
            // 
            SearchTb.Font = new Font("Arial Unicode MS", 13.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            SearchTb.ForeColor = Color.Red;
            SearchTb.Location = new Point(23, 461);
            SearchTb.Multiline = true;
            SearchTb.Name = "SearchTb";
            SearchTb.PlaceholderText = "Search Sales User";
            SearchTb.Size = new Size(245, 39);
            SearchTb.TabIndex = 55;
            SearchTb.TextChanged += SearchTb_TextChanged;
            // 
            // SalesDGV
            // 
            dataGridViewCellStyle5.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = Color.FromArgb(255, 255, 192);
            dataGridViewCellStyle5.Font = new Font("Arial Narrow", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            dataGridViewCellStyle5.ForeColor = Color.Black;
            dataGridViewCellStyle5.SelectionBackColor = Color.Yellow;
            dataGridViewCellStyle5.SelectionForeColor = Color.FromArgb(0, 192, 0);
            SalesDGV.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            SalesDGV.BackgroundColor = Color.White;
            SalesDGV.BorderStyle = BorderStyle.None;
            SalesDGV.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle6.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = Color.FromArgb(255, 255, 192);
            dataGridViewCellStyle6.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            dataGridViewCellStyle6.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = Color.Yellow;
            dataGridViewCellStyle6.SelectionForeColor = Color.FromArgb(0, 192, 0);
            dataGridViewCellStyle6.WrapMode = DataGridViewTriState.True;
            SalesDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            SalesDGV.ColumnHeadersHeight = 32;
            dataGridViewCellStyle7.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.BackColor = Color.FromArgb(255, 255, 192);
            dataGridViewCellStyle7.Font = new Font("Arial Narrow", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            dataGridViewCellStyle7.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle7.SelectionBackColor = Color.Yellow;
            dataGridViewCellStyle7.SelectionForeColor = Color.FromArgb(0, 192, 0);
            dataGridViewCellStyle7.WrapMode = DataGridViewTriState.False;
            SalesDGV.DefaultCellStyle = dataGridViewCellStyle7;
            SalesDGV.Location = new Point(23, 532);
            SalesDGV.Name = "SalesDGV";
            dataGridViewCellStyle8.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.BackColor = SystemColors.Control;
            dataGridViewCellStyle8.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            dataGridViewCellStyle8.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = DataGridViewTriState.True;
            SalesDGV.RowHeadersDefaultCellStyle = dataGridViewCellStyle8;
            SalesDGV.RowHeadersWidth = 51;
            SalesDGV.Size = new Size(817, 439);
            SalesDGV.TabIndex = 36;
            // 
            // pictureBox13
            // 
            pictureBox13.Image = (Image)resources.GetObject("pictureBox13.Image");
            pictureBox13.Location = new Point(1260, 477);
            pictureBox13.Name = "pictureBox13";
            pictureBox13.Size = new Size(56, 52);
            pictureBox13.TabIndex = 13;
            pictureBox13.TabStop = false;
            pictureBox13.Click += pictureBox13_Click;
            // 
            // Chart1
            // 
            Chart1.BackColor = Color.FromArgb(192, 255, 192);
            Chart1.BorderlineColor = Color.Transparent;
            Chart1.BorderlineDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Solid;
            Chart1.BorderlineWidth = 10;
            chartArea1.Name = "ChartArea1";
            Chart1.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            Chart1.Legends.Add(legend1);
            Chart1.Location = new Point(979, 549);
            Chart1.Name = "Chart1";
            series1.BorderColor = Color.FromArgb(128, 255, 128);
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.SplineArea;
            series1.Color = Color.Green;
            series1.Legend = "Legend1";
            series1.Name = "LineChart";
            series1.Palette = System.Windows.Forms.DataVisualization.Charting.ChartColorPalette.Excel;
            series1.ShadowColor = Color.White;
            series1.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.DateTime;
            series1.YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Single;
            Chart1.Series.Add(series1);
            Chart1.Size = new Size(828, 375);
            Chart1.TabIndex = 11;
            Chart1.Text = "chart1";
            Chart1.Click += Chart1_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial Rounded MT Bold", 22.2F, FontStyle.Italic, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.FromArgb(0, 0, 192);
            label3.Location = new Point(712, 74);
            label3.Name = "label3";
            label3.Size = new Size(286, 43);
            label3.TabIndex = 10;
            label3.Text = "Shop Analytics";
            // 
            // panel3
            // 
            panel3.BackColor = Color.Green;
            panel3.BorderStyle = BorderStyle.FixedSingle;
            panel3.Controls.Add(pictureBox11);
            panel3.Controls.Add(SalesLbl);
            panel3.Controls.Add(label5);
            panel3.Location = new Point(372, 163);
            panel3.Name = "panel3";
            panel3.Size = new Size(294, 218);
            panel3.TabIndex = 8;
            // 
            // pictureBox11
            // 
            pictureBox11.Image = (Image)resources.GetObject("pictureBox11.Image");
            pictureBox11.Location = new Point(20, 71);
            pictureBox11.Name = "pictureBox11";
            pictureBox11.Size = new Size(88, 112);
            pictureBox11.TabIndex = 12;
            pictureBox11.TabStop = false;
            // 
            // SalesLbl
            // 
            SalesLbl.AutoSize = true;
            SalesLbl.Font = new Font("Arial Rounded MT Bold", 18F, FontStyle.Italic, GraphicsUnit.Point, 0);
            SalesLbl.ForeColor = Color.White;
            SalesLbl.Location = new Point(125, 112);
            SalesLbl.Name = "SalesLbl";
            SalesLbl.Size = new Size(83, 34);
            SalesLbl.TabIndex = 13;
            SalesLbl.Text = "Num";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Arial Rounded MT Bold", 19.8000011F, FontStyle.Italic, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.White;
            label5.Location = new Point(92, 12);
            label5.Name = "label5";
            label5.Size = new Size(116, 39);
            label5.TabIndex = 12;
            label5.Text = "Sales ";
            // 
            // panel2
            // 
            panel2.BackColor = Color.Black;
            panel2.BorderStyle = BorderStyle.FixedSingle;
            panel2.Controls.Add(StockLbl);
            panel2.Controls.Add(pictureBox10);
            panel2.Controls.Add(label4);
            panel2.Location = new Point(23, 163);
            panel2.Name = "panel2";
            panel2.Size = new Size(319, 218);
            panel2.TabIndex = 7;
            // 
            // StockLbl
            // 
            StockLbl.AutoSize = true;
            StockLbl.Font = new Font("Arial Rounded MT Bold", 18F, FontStyle.Italic, GraphicsUnit.Point, 0);
            StockLbl.ForeColor = Color.Gold;
            StockLbl.Location = new Point(147, 112);
            StockLbl.Name = "StockLbl";
            StockLbl.Size = new Size(83, 34);
            StockLbl.TabIndex = 12;
            StockLbl.Text = "Num";
            StockLbl.Click += StockLbl_Click;
            // 
            // pictureBox10
            // 
            pictureBox10.Image = (Image)resources.GetObject("pictureBox10.Image");
            pictureBox10.Location = new Point(28, 73);
            pictureBox10.Name = "pictureBox10";
            pictureBox10.Size = new Size(113, 112);
            pictureBox10.TabIndex = 11;
            pictureBox10.TabStop = false;
            pictureBox10.Click += pictureBox10_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial Rounded MT Bold", 19.8000011F, FontStyle.Italic, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.Gold;
            label4.Location = new Point(33, 12);
            label4.Name = "label4";
            label4.Size = new Size(254, 39);
            label4.TabIndex = 11;
            label4.Text = "Product Stock";
            label4.Click += label4_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial Rounded MT Bold", 24F, FontStyle.Italic, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.LightSeaGreen;
            label2.Location = new Point(1332, 477);
            label2.Name = "label2";
            label2.Size = new Size(254, 46);
            label2.TabIndex = 5;
            label2.Text = "Sales Trade";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial Rounded MT Bold", 22.2F, FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Red;
            label1.Location = new Point(136, 74);
            label1.Name = "label1";
            label1.Size = new Size(317, 43);
            label1.TabIndex = 3;
            label1.Text = "Shop Dashboard";
            label1.Click += label1_Click;
            // 
            // pictureBox9
            // 
            pictureBox9.Image = (Image)resources.GetObject("pictureBox9.Image");
            pictureBox9.Location = new Point(1754, 23);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(53, 58);
            pictureBox9.TabIndex = 2;
            pictureBox9.TabStop = false;
            pictureBox9.Click += pictureBox9_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(57, 40);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(73, 77);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // pictureBox8
            // 
            pictureBox8.Image = (Image)resources.GetObject("pictureBox8.Image");
            pictureBox8.Location = new Point(3, 884);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(53, 58);
            pictureBox8.TabIndex = 13;
            pictureBox8.TabStop = false;
            pictureBox8.Click += pictureBox8_Click;
            // 
            // pictureBox7
            // 
            pictureBox7.Image = (Image)resources.GetObject("pictureBox7.Image");
            pictureBox7.Location = new Point(3, 540);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(53, 58);
            pictureBox7.TabIndex = 14;
            pictureBox7.TabStop = false;
            pictureBox7.Click += pictureBox7_Click;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = (Image)resources.GetObject("pictureBox6.Image");
            pictureBox6.Location = new Point(3, 446);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(53, 58);
            pictureBox6.TabIndex = 15;
            pictureBox6.TabStop = false;
            pictureBox6.Click += pictureBox6_Click;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(2, 354);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(53, 58);
            pictureBox5.TabIndex = 16;
            pictureBox5.TabStop = false;
            pictureBox5.Click += pictureBox5_Click;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(3, 263);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(53, 58);
            pictureBox4.TabIndex = 17;
            pictureBox4.TabStop = false;
            pictureBox4.Click += pictureBox4_Click;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(3, 163);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(53, 58);
            pictureBox3.TabIndex = 18;
            pictureBox3.TabStop = false;
            pictureBox3.Click += pictureBox3_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(3, 12);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(53, 58);
            pictureBox2.TabIndex = 12;
            pictureBox2.TabStop = false;
            // 
            // pictureBox14
            // 
            pictureBox14.Image = (Image)resources.GetObject("pictureBox14.Image");
            pictureBox14.Location = new Point(2, 739);
            pictureBox14.Name = "pictureBox14";
            pictureBox14.Size = new Size(54, 64);
            pictureBox14.TabIndex = 62;
            pictureBox14.TabStop = false;
            pictureBox14.Click += pictureBox14_Click;
            // 
            // pictureBox15
            // 
            pictureBox15.Image = (Image)resources.GetObject("pictureBox15.Image");
            pictureBox15.Location = new Point(1, 647);
            pictureBox15.Name = "pictureBox15";
            pictureBox15.Size = new Size(55, 64);
            pictureBox15.TabIndex = 61;
            pictureBox15.TabStop = false;
            pictureBox15.Click += pictureBox15_Click;
            // 
            // Dashboard
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(0, 192, 0);
            ClientSize = new Size(1901, 983);
            Controls.Add(pictureBox14);
            Controls.Add(panel1);
            Controls.Add(pictureBox15);
            Controls.Add(pictureBox8);
            Controls.Add(pictureBox7);
            Controls.Add(pictureBox6);
            Controls.Add(pictureBox5);
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox2);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Dashboard";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Dashboard";
            Load += Dashboard_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).EndInit();
            ((System.ComponentModel.ISupportInitialize)SalaryDGV).EndInit();
            ((System.ComponentModel.ISupportInitialize)RefreshImg).EndInit();
            ((System.ComponentModel.ISupportInitialize)SearchImg).EndInit();
            ((System.ComponentModel.ISupportInitialize)SalesDGV).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).EndInit();
            ((System.ComponentModel.ISupportInitialize)Chart1).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox14).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox15).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private PictureBox pictureBox9;
        private PictureBox pictureBox1;
        private PictureBox pictureBox8;
        private PictureBox pictureBox7;
        private PictureBox pictureBox6;
        private PictureBox pictureBox5;
        private PictureBox pictureBox4;
        private PictureBox pictureBox3;
        private PictureBox pictureBox2;
        private Label label1;
        private Label label2;
        private Panel panel3;
        private Panel panel2;
        private Label label3;
        private Label label4;
        private Label label5;
        private PictureBox pictureBox10;
        private Label SalesLbl;
        private Label StockLbl;
        private System.Windows.Forms.DataVisualization.Charting.Chart Chart1;
        private PictureBox pictureBox11;
        private PictureBox pictureBox13;
        private PictureBox pictureBox14;
        private PictureBox pictureBox15;
        private DataGridView SalesDGV;
        private PictureBox RefreshImg;
        private PictureBox SearchImg;
        private TextBox SearchTb;
        private DataGridView SalaryDGV;
        private DateTimePicker SartDate;
        private DateTimePicker EndDate;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label9;
        private PictureBox pictureBox12;
    }
}