﻿namespace STATIONERY_SHOP
{
    partial class Stock
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Stock));
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle6 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle7 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle8 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle9 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle10 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle11 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle12 = new DataGridViewCellStyle();
            pictureBox2 = new PictureBox();
            RefreshImg = new PictureBox();
            SearchImg = new PictureBox();
            SearchTb = new TextBox();
            StockDGV = new DataGridView();
            pictureBox7 = new PictureBox();
            pictureBox6 = new PictureBox();
            pictureBox5 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox13 = new PictureBox();
            label1 = new Label();
            pictureBox9 = new PictureBox();
            pictureBox1 = new PictureBox();
            pictureBox8 = new PictureBox();
            panel1 = new Panel();
            label8 = new Label();
            MiniDGV = new DataGridView();
            panel4 = new Panel();
            MiniLbl = new Label();
            pictureBox14 = new PictureBox();
            label7 = new Label();
            panel3 = new Panel();
            OutStockLbl = new Label();
            pictureBox12 = new PictureBox();
            label6 = new Label();
            panel2 = new Panel();
            StockLbl = new Label();
            pictureBox11 = new PictureBox();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            OutstockDGV = new DataGridView();
            pictureBox10 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)RefreshImg).BeginInit();
            ((System.ComponentModel.ISupportInitialize)SearchImg).BeginInit();
            ((System.ComponentModel.ISupportInitialize)StockDGV).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)MiniDGV).BeginInit();
            panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox14).BeginInit();
            panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).BeginInit();
            ((System.ComponentModel.ISupportInitialize)OutstockDGV).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).BeginInit();
            SuspendLayout();
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(2, 13);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(53, 58);
            pictureBox2.TabIndex = 61;
            pictureBox2.TabStop = false;
            // 
            // RefreshImg
            // 
            RefreshImg.Image = (Image)resources.GetObject("RefreshImg.Image");
            RefreshImg.Location = new Point(1072, 53);
            RefreshImg.Name = "RefreshImg";
            RefreshImg.Size = new Size(57, 52);
            RefreshImg.TabIndex = 54;
            RefreshImg.TabStop = false;
            RefreshImg.Click += RefreshImg_Click;
            // 
            // SearchImg
            // 
            SearchImg.Image = (Image)resources.GetObject("SearchImg.Image");
            SearchImg.Location = new Point(1000, 53);
            SearchImg.Name = "SearchImg";
            SearchImg.Size = new Size(57, 52);
            SearchImg.TabIndex = 53;
            SearchImg.TabStop = false;
            SearchImg.Click += SearchImg_Click;
            // 
            // SearchTb
            // 
            SearchTb.Font = new Font("Arial Unicode MS", 13.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            SearchTb.ForeColor = Color.Red;
            SearchTb.Location = new Point(798, 53);
            SearchTb.Multiline = true;
            SearchTb.Name = "SearchTb";
            SearchTb.PlaceholderText = "Search Item";
            SearchTb.Size = new Size(196, 49);
            SearchTb.TabIndex = 52;
            // 
            // StockDGV
            // 
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = Color.FromArgb(255, 192, 192);
            dataGridViewCellStyle1.Font = new Font("Arial", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            dataGridViewCellStyle1.ForeColor = Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = Color.Red;
            dataGridViewCellStyle1.SelectionForeColor = Color.White;
            StockDGV.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            StockDGV.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            StockDGV.BackgroundColor = Color.White;
            StockDGV.BorderStyle = BorderStyle.None;
            StockDGV.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = Color.Red;
            dataGridViewCellStyle2.Font = new Font("Arial", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            dataGridViewCellStyle2.ForeColor = Color.White;
            dataGridViewCellStyle2.SelectionBackColor = Color.Red;
            dataGridViewCellStyle2.SelectionForeColor = Color.White;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            StockDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            StockDGV.ColumnHeadersHeight = 45;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = Color.FromArgb(255, 128, 128);
            dataGridViewCellStyle3.Font = new Font("Arial", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            dataGridViewCellStyle3.ForeColor = Color.Red;
            dataGridViewCellStyle3.SelectionBackColor = Color.Red;
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            StockDGV.DefaultCellStyle = dataGridViewCellStyle3;
            StockDGV.GridColor = Color.Red;
            StockDGV.ImeMode = ImeMode.On;
            StockDGV.Location = new Point(16, 446);
            StockDGV.Name = "StockDGV";
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = Color.FromArgb(255, 128, 128);
            dataGridViewCellStyle4.Font = new Font("Arial Narrow", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            dataGridViewCellStyle4.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = Color.Red;
            dataGridViewCellStyle4.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = DataGridViewTriState.True;
            StockDGV.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            StockDGV.RowHeadersWidth = 70;
            StockDGV.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            StockDGV.Size = new Size(584, 411);
            StockDGV.TabIndex = 50;
            StockDGV.CellContentClick += StockGDV_CellContentClick;
            // 
            // pictureBox7
            // 
            pictureBox7.Image = (Image)resources.GetObject("pictureBox7.Image");
            pictureBox7.Location = new Point(3, 540);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(53, 58);
            pictureBox7.TabIndex = 62;
            pictureBox7.TabStop = false;
            pictureBox7.Click += pictureBox7_Click;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = (Image)resources.GetObject("pictureBox6.Image");
            pictureBox6.Location = new Point(3, 446);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(53, 58);
            pictureBox6.TabIndex = 63;
            pictureBox6.TabStop = false;
            pictureBox6.Click += pictureBox6_Click;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(2, 354);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(53, 58);
            pictureBox5.TabIndex = 64;
            pictureBox5.TabStop = false;
            pictureBox5.Click += pictureBox5_Click;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(3, 264);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(53, 58);
            pictureBox4.TabIndex = 65;
            pictureBox4.TabStop = false;
            pictureBox4.Click += pictureBox4_Click;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(2, 164);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(53, 58);
            pictureBox3.TabIndex = 66;
            pictureBox3.TabStop = false;
            pictureBox3.Click += pictureBox3_Click;
            // 
            // pictureBox13
            // 
            pictureBox13.Image = (Image)resources.GetObject("pictureBox13.Image");
            pictureBox13.Location = new Point(2, 739);
            pictureBox13.Name = "pictureBox13";
            pictureBox13.Size = new Size(60, 64);
            pictureBox13.TabIndex = 68;
            pictureBox13.TabStop = false;
            pictureBox13.Click += pictureBox13_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial Rounded MT Bold", 22.2F, FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Red;
            label1.Location = new Point(123, 46);
            label1.Name = "label1";
            label1.Size = new Size(293, 43);
            label1.TabIndex = 4;
            label1.Text = "Manage Stocks";
            // 
            // pictureBox9
            // 
            pictureBox9.Image = (Image)resources.GetObject("pictureBox9.Image");
            pictureBox9.Location = new Point(1749, 12);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(53, 58);
            pictureBox9.TabIndex = 2;
            pictureBox9.TabStop = false;
            pictureBox9.Click += pictureBox9_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(44, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(73, 77);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // pictureBox8
            // 
            pictureBox8.Image = (Image)resources.GetObject("pictureBox8.Image");
            pictureBox8.Location = new Point(2, 894);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(53, 58);
            pictureBox8.TabIndex = 67;
            pictureBox8.TabStop = false;
            pictureBox8.Click += pictureBox8_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.Controls.Add(label8);
            panel1.Controls.Add(MiniDGV);
            panel1.Controls.Add(panel4);
            panel1.Controls.Add(panel3);
            panel1.Controls.Add(panel2);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(OutstockDGV);
            panel1.Controls.Add(RefreshImg);
            panel1.Controls.Add(SearchImg);
            panel1.Controls.Add(SearchTb);
            panel1.Controls.Add(StockDGV);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(pictureBox9);
            panel1.Controls.Add(pictureBox1);
            panel1.Dock = DockStyle.Right;
            panel1.Font = new Font("Arial Rounded MT Bold", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            panel1.ForeColor = Color.Red;
            panel1.Location = new Point(62, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1839, 983);
            panel1.TabIndex = 60;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Arial Rounded MT Bold", 18F, FontStyle.Italic, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.FromArgb(0, 192, 0);
            label8.Location = new Point(786, 378);
            label8.Name = "label8";
            label8.Size = new Size(323, 34);
            label8.TabIndex = 62;
            label8.Text = " Minimum Stocks List";
            // 
            // MiniDGV
            // 
            dataGridViewCellStyle5.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = Color.FromArgb(255, 192, 192);
            dataGridViewCellStyle5.Font = new Font("Arial", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            dataGridViewCellStyle5.ForeColor = Color.Black;
            dataGridViewCellStyle5.SelectionBackColor = Color.Red;
            dataGridViewCellStyle5.SelectionForeColor = Color.White;
            MiniDGV.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            MiniDGV.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            MiniDGV.BackgroundColor = Color.White;
            MiniDGV.BorderStyle = BorderStyle.None;
            MiniDGV.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle6.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = Color.Red;
            dataGridViewCellStyle6.Font = new Font("Arial", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            dataGridViewCellStyle6.ForeColor = Color.White;
            dataGridViewCellStyle6.SelectionBackColor = Color.Red;
            dataGridViewCellStyle6.SelectionForeColor = Color.White;
            dataGridViewCellStyle6.WrapMode = DataGridViewTriState.True;
            MiniDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            MiniDGV.ColumnHeadersHeight = 45;
            dataGridViewCellStyle7.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.BackColor = Color.FromArgb(255, 128, 128);
            dataGridViewCellStyle7.Font = new Font("Arial", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            dataGridViewCellStyle7.ForeColor = Color.Red;
            dataGridViewCellStyle7.SelectionBackColor = Color.Red;
            dataGridViewCellStyle7.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = DataGridViewTriState.False;
            MiniDGV.DefaultCellStyle = dataGridViewCellStyle7;
            MiniDGV.GridColor = Color.Red;
            MiniDGV.ImeMode = ImeMode.On;
            MiniDGV.Location = new Point(641, 446);
            MiniDGV.Name = "MiniDGV";
            dataGridViewCellStyle8.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.BackColor = Color.FromArgb(255, 128, 128);
            dataGridViewCellStyle8.Font = new Font("Arial Narrow", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            dataGridViewCellStyle8.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = Color.Red;
            dataGridViewCellStyle8.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = DataGridViewTriState.True;
            MiniDGV.RowHeadersDefaultCellStyle = dataGridViewCellStyle8;
            MiniDGV.RowHeadersWidth = 70;
            MiniDGV.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            MiniDGV.Size = new Size(584, 411);
            MiniDGV.TabIndex = 61;
            // 
            // panel4
            // 
            panel4.BackColor = Color.Black;
            panel4.BorderStyle = BorderStyle.FixedSingle;
            panel4.Controls.Add(MiniLbl);
            panel4.Controls.Add(pictureBox14);
            panel4.Controls.Add(label7);
            panel4.Location = new Point(766, 147);
            panel4.Name = "panel4";
            panel4.Size = new Size(391, 218);
            panel4.TabIndex = 60;
            // 
            // MiniLbl
            // 
            MiniLbl.AutoSize = true;
            MiniLbl.Font = new Font("Arial Rounded MT Bold", 18F, FontStyle.Italic, GraphicsUnit.Point, 0);
            MiniLbl.ForeColor = Color.Gold;
            MiniLbl.Location = new Point(164, 102);
            MiniLbl.Name = "MiniLbl";
            MiniLbl.Size = new Size(83, 34);
            MiniLbl.TabIndex = 12;
            MiniLbl.Text = "Num";
            // 
            // pictureBox14
            // 
            pictureBox14.Image = (Image)resources.GetObject("pictureBox14.Image");
            pictureBox14.Location = new Point(19, 63);
            pictureBox14.Name = "pictureBox14";
            pictureBox14.Size = new Size(107, 112);
            pictureBox14.TabIndex = 11;
            pictureBox14.TabStop = false;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Arial Rounded MT Bold", 19.8000011F, FontStyle.Italic, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.Gold;
            label7.Location = new Point(45, 4);
            label7.Name = "label7";
            label7.Size = new Size(317, 39);
            label7.TabIndex = 11;
            label7.Text = "Soon Out of Stock";
            // 
            // panel3
            // 
            panel3.BackColor = Color.Black;
            panel3.BorderStyle = BorderStyle.FixedSingle;
            panel3.Controls.Add(OutStockLbl);
            panel3.Controls.Add(pictureBox12);
            panel3.Controls.Add(label6);
            panel3.Location = new Point(1391, 147);
            panel3.Name = "panel3";
            panel3.Size = new Size(358, 218);
            panel3.TabIndex = 59;
            // 
            // OutStockLbl
            // 
            OutStockLbl.AutoSize = true;
            OutStockLbl.Font = new Font("Arial Rounded MT Bold", 18F, FontStyle.Italic, GraphicsUnit.Point, 0);
            OutStockLbl.ForeColor = Color.Gold;
            OutStockLbl.Location = new Point(163, 102);
            OutStockLbl.Name = "OutStockLbl";
            OutStockLbl.Size = new Size(83, 34);
            OutStockLbl.TabIndex = 12;
            OutStockLbl.Text = "Num";
            // 
            // pictureBox12
            // 
            pictureBox12.Image = (Image)resources.GetObject("pictureBox12.Image");
            pictureBox12.Location = new Point(3, 63);
            pictureBox12.Name = "pictureBox12";
            pictureBox12.Size = new Size(107, 112);
            pictureBox12.TabIndex = 11;
            pictureBox12.TabStop = false;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Arial Rounded MT Bold", 19.8000011F, FontStyle.Italic, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.Gold;
            label6.Location = new Point(34, 4);
            label6.Name = "label6";
            label6.Size = new Size(322, 39);
            label6.TabIndex = 11;
            label6.Text = "Out of Stock Items";
            // 
            // panel2
            // 
            panel2.BackColor = Color.Black;
            panel2.BorderStyle = BorderStyle.FixedSingle;
            panel2.Controls.Add(StockLbl);
            panel2.Controls.Add(pictureBox11);
            panel2.Controls.Add(label4);
            panel2.Location = new Point(79, 147);
            panel2.Name = "panel2";
            panel2.Size = new Size(382, 218);
            panel2.TabIndex = 58;
            panel2.Paint += panel2_Paint;
            // 
            // StockLbl
            // 
            StockLbl.AutoSize = true;
            StockLbl.Font = new Font("Arial Rounded MT Bold", 18F, FontStyle.Italic, GraphicsUnit.Point, 0);
            StockLbl.ForeColor = Color.Gold;
            StockLbl.Location = new Point(164, 102);
            StockLbl.Name = "StockLbl";
            StockLbl.Size = new Size(83, 34);
            StockLbl.TabIndex = 12;
            StockLbl.Text = "Num";
            // 
            // pictureBox11
            // 
            pictureBox11.Image = (Image)resources.GetObject("pictureBox11.Image");
            pictureBox11.Location = new Point(19, 63);
            pictureBox11.Name = "pictureBox11";
            pictureBox11.Size = new Size(107, 112);
            pictureBox11.TabIndex = 11;
            pictureBox11.TabStop = false;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial Rounded MT Bold", 19.8000011F, FontStyle.Italic, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.Gold;
            label4.Location = new Point(49, 4);
            label4.Name = "label4";
            label4.Size = new Size(212, 39);
            label4.TabIndex = 11;
            label4.Text = "Stock Items";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial Rounded MT Bold", 18F, FontStyle.Italic, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.FromArgb(0, 192, 0);
            label3.Location = new Point(1428, 378);
            label3.Name = "label3";
            label3.Size = new Size(281, 34);
            label3.TabIndex = 57;
            label3.Text = " Out of Stocks List";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial Rounded MT Bold", 18F, FontStyle.Italic, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.FromArgb(0, 192, 0);
            label2.Location = new Point(159, 378);
            label2.Name = "label2";
            label2.Size = new Size(184, 34);
            label2.TabIndex = 56;
            label2.Text = " Stocks List";
            // 
            // OutstockDGV
            // 
            dataGridViewCellStyle9.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle9.BackColor = Color.FromArgb(255, 192, 192);
            dataGridViewCellStyle9.Font = new Font("Arial", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            dataGridViewCellStyle9.ForeColor = Color.Black;
            dataGridViewCellStyle9.SelectionBackColor = Color.Red;
            dataGridViewCellStyle9.SelectionForeColor = Color.White;
            OutstockDGV.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle9;
            OutstockDGV.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            OutstockDGV.BackgroundColor = Color.White;
            OutstockDGV.BorderStyle = BorderStyle.None;
            OutstockDGV.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle10.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle10.BackColor = Color.Red;
            dataGridViewCellStyle10.Font = new Font("Arial", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            dataGridViewCellStyle10.ForeColor = Color.White;
            dataGridViewCellStyle10.SelectionBackColor = Color.Red;
            dataGridViewCellStyle10.SelectionForeColor = Color.White;
            dataGridViewCellStyle10.WrapMode = DataGridViewTriState.True;
            OutstockDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            OutstockDGV.ColumnHeadersHeight = 45;
            dataGridViewCellStyle11.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle11.BackColor = Color.FromArgb(255, 128, 128);
            dataGridViewCellStyle11.Font = new Font("Arial", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            dataGridViewCellStyle11.ForeColor = Color.Red;
            dataGridViewCellStyle11.SelectionBackColor = Color.Red;
            dataGridViewCellStyle11.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = DataGridViewTriState.False;
            OutstockDGV.DefaultCellStyle = dataGridViewCellStyle11;
            OutstockDGV.GridColor = Color.Red;
            OutstockDGV.ImeMode = ImeMode.On;
            OutstockDGV.Location = new Point(1253, 446);
            OutstockDGV.Name = "OutstockDGV";
            dataGridViewCellStyle12.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle12.BackColor = Color.FromArgb(255, 128, 128);
            dataGridViewCellStyle12.Font = new Font("Arial Narrow", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            dataGridViewCellStyle12.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle12.SelectionBackColor = Color.Red;
            dataGridViewCellStyle12.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = DataGridViewTriState.True;
            OutstockDGV.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            OutstockDGV.RowHeadersWidth = 70;
            OutstockDGV.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            OutstockDGV.Size = new Size(574, 411);
            OutstockDGV.TabIndex = 55;
            OutstockDGV.CellContentClick += dataGridView1_CellContentClick;
            // 
            // pictureBox10
            // 
            pictureBox10.Image = (Image)resources.GetObject("pictureBox10.Image");
            pictureBox10.Location = new Point(1, 647);
            pictureBox10.Name = "pictureBox10";
            pictureBox10.Size = new Size(54, 64);
            pictureBox10.TabIndex = 69;
            pictureBox10.TabStop = false;
            pictureBox10.Click += pictureBox10_Click;
            // 
            // Stock
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(0, 192, 0);
            ClientSize = new Size(1901, 983);
            Controls.Add(pictureBox10);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox7);
            Controls.Add(pictureBox6);
            Controls.Add(pictureBox5);
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox13);
            Controls.Add(pictureBox8);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Stock";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Stock";
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)RefreshImg).EndInit();
            ((System.ComponentModel.ISupportInitialize)SearchImg).EndInit();
            ((System.ComponentModel.ISupportInitialize)StockDGV).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)MiniDGV).EndInit();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox14).EndInit();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).EndInit();
            ((System.ComponentModel.ISupportInitialize)OutstockDGV).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private PictureBox pictureBox2;
        private PictureBox RefreshImg;
        private PictureBox SearchImg;
        private TextBox SearchTb;
        private DataGridView StockDGV;
        private PictureBox pictureBox7;
        private PictureBox pictureBox6;
        private PictureBox pictureBox5;
        private PictureBox pictureBox4;
        private PictureBox pictureBox3;
        private PictureBox pictureBox13;
        private Label label1;
        private PictureBox pictureBox9;
        private PictureBox pictureBox1;
        private PictureBox pictureBox8;
        private Panel panel1;
        private DataGridView OutstockDGV;
        private Label label3;
        private Label label2;
        private PictureBox pictureBox10;
        private Panel panel3;
        private Label OutStockLbl;
        private PictureBox pictureBox12;
        private Label label6;
        private Panel panel2;
        private Label StockLbl;
        private PictureBox pictureBox11;
        private Label label4;
        private Panel panel4;
        private Label MiniLbl;
        private PictureBox pictureBox14;
        private Label label7;
        private Label label8;
        private DataGridView MiniDGV;
    }
}