﻿namespace STATIONERY_SHOP
{
    partial class Users
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Users));
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            pictureBox3 = new PictureBox();
            pictureBox8 = new PictureBox();
            pictureBox7 = new PictureBox();
            pictureBox6 = new PictureBox();
            pictureBox5 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox2 = new PictureBox();
            label9 = new Label();
            DeleteBtn = new Button();
            EditBtn = new Button();
            SaveBtn = new Button();
            UDOB = new DateTimePicker();
            GenCb = new ComboBox();
            label7 = new Label();
            PhoneTb = new TextBox();
            label6 = new Label();
            PasswordTb = new TextBox();
            label5 = new Label();
            EmailTb = new TextBox();
            label4 = new Label();
            label3 = new Label();
            UNameTb = new TextBox();
            label2 = new Label();
            pictureBox9 = new PictureBox();
            label1 = new Label();
            pictureBox16 = new PictureBox();
            panel1 = new Panel();
            pictureBox1 = new PictureBox();
            pictureBox10 = new PictureBox();
            pictureBox11 = new PictureBox();
            UserGDV = new DataGridView();
            pictureBox12 = new PictureBox();
            pictureBox13 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox16).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).BeginInit();
            ((System.ComponentModel.ISupportInitialize)UserGDV).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).BeginInit();
            SuspendLayout();
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(6, 166);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(53, 58);
            pictureBox3.TabIndex = 5;
            pictureBox3.TabStop = false;
            pictureBox3.Click += pictureBox3_Click;
            // 
            // pictureBox8
            // 
            pictureBox8.Image = (Image)resources.GetObject("pictureBox8.Image");
            pictureBox8.Location = new Point(6, 896);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(53, 58);
            pictureBox8.TabIndex = 6;
            pictureBox8.TabStop = false;
            pictureBox8.Click += pictureBox8_Click;
            // 
            // pictureBox7
            // 
            pictureBox7.Image = (Image)resources.GetObject("pictureBox7.Image");
            pictureBox7.Location = new Point(3, 540);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(53, 58);
            pictureBox7.TabIndex = 7;
            pictureBox7.TabStop = false;
            pictureBox7.Click += pictureBox7_Click;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = (Image)resources.GetObject("pictureBox6.Image");
            pictureBox6.Location = new Point(3, 446);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(53, 58);
            pictureBox6.TabIndex = 8;
            pictureBox6.TabStop = false;
            pictureBox6.Click += pictureBox6_Click;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(2, 354);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(53, 58);
            pictureBox5.TabIndex = 9;
            pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(6, 266);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(53, 58);
            pictureBox4.TabIndex = 10;
            pictureBox4.TabStop = false;
            pictureBox4.Click += pictureBox4_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(6, 15);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(53, 58);
            pictureBox2.TabIndex = 4;
            pictureBox2.TabStop = false;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Arial Unicode MS", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.FromArgb(0, 192, 0);
            label9.Location = new Point(728, 425);
            label9.Name = "label9";
            label9.Size = new Size(161, 40);
            label9.TabIndex = 26;
            label9.Text = "Users List";
            // 
            // DeleteBtn
            // 
            DeleteBtn.BackColor = Color.Red;
            DeleteBtn.Font = new Font("Arial Unicode MS", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            DeleteBtn.ForeColor = Color.White;
            DeleteBtn.Location = new Point(1021, 318);
            DeleteBtn.Name = "DeleteBtn";
            DeleteBtn.Size = new Size(316, 58);
            DeleteBtn.TabIndex = 25;
            DeleteBtn.Text = "DELETE USER";
            DeleteBtn.UseVisualStyleBackColor = false;
            DeleteBtn.Click += DeleteBtn_Click;
            // 
            // EditBtn
            // 
            EditBtn.BackColor = Color.Black;
            EditBtn.Font = new Font("Arial Unicode MS", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            EditBtn.ForeColor = Color.White;
            EditBtn.Location = new Point(728, 318);
            EditBtn.Name = "EditBtn";
            EditBtn.Size = new Size(257, 58);
            EditBtn.TabIndex = 24;
            EditBtn.Text = "EDIT USER";
            EditBtn.UseVisualStyleBackColor = false;
            EditBtn.Click += EditBtn_Click;
            // 
            // SaveBtn
            // 
            SaveBtn.BackColor = Color.Green;
            SaveBtn.Font = new Font("Arial Unicode MS", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            SaveBtn.ForeColor = Color.White;
            SaveBtn.Location = new Point(437, 318);
            SaveBtn.Name = "SaveBtn";
            SaveBtn.Size = new Size(263, 58);
            SaveBtn.TabIndex = 23;
            SaveBtn.Text = "ADD USER";
            SaveBtn.UseVisualStyleBackColor = false;
            SaveBtn.Click += SaveBtn_Click;
            // 
            // UDOB
            // 
            UDOB.CalendarFont = new Font("Arial Narrow", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            UDOB.CalendarForeColor = Color.Red;
            UDOB.CalendarMonthBackground = Color.FromArgb(255, 192, 192);
            UDOB.CalendarTitleBackColor = Color.FromArgb(255, 128, 128);
            UDOB.CalendarTitleForeColor = Color.Red;
            UDOB.CalendarTrailingForeColor = Color.Red;
            UDOB.Font = new Font("Arial Narrow", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            UDOB.Location = new Point(615, 212);
            UDOB.Name = "UDOB";
            UDOB.RightToLeft = RightToLeft.Yes;
            UDOB.RightToLeftLayout = true;
            UDOB.Size = new Size(221, 30);
            UDOB.TabIndex = 22;
            // 
            // GenCb
            // 
            GenCb.FormattingEnabled = true;
            GenCb.Items.AddRange(new object[] { "Select Gender ", "Male", "Female", "Transgender" });
            GenCb.Location = new Point(383, 212);
            GenCb.Name = "GenCb";
            GenCb.Size = new Size(173, 31);
            GenCb.TabIndex = 21;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Arial Unicode MS", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.FromArgb(0, 192, 0);
            label7.Location = new Point(1550, 163);
            label7.Name = "label7";
            label7.Size = new Size(110, 40);
            label7.TabIndex = 19;
            label7.Text = "Phone";
            // 
            // PhoneTb
            // 
            PhoneTb.Font = new Font("Arial Unicode MS", 13.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            PhoneTb.ForeColor = Color.Red;
            PhoneTb.Location = new Point(1516, 206);
            PhoneTb.Multiline = true;
            PhoneTb.Name = "PhoneTb";
            PhoneTb.PlaceholderText = "Phone Number";
            PhoneTb.Size = new Size(196, 49);
            PhoneTb.TabIndex = 18;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Arial Unicode MS", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.FromArgb(0, 192, 0);
            label6.Location = new Point(1242, 163);
            label6.Name = "label6";
            label6.Size = new Size(158, 40);
            label6.TabIndex = 17;
            label6.Text = "Password";
            // 
            // PasswordTb
            // 
            PasswordTb.Font = new Font("Arial Unicode MS", 13.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            PasswordTb.ForeColor = Color.Red;
            PasswordTb.Location = new Point(1242, 206);
            PasswordTb.Multiline = true;
            PasswordTb.Name = "PasswordTb";
            PasswordTb.PlaceholderText = "Enter Password";
            PasswordTb.Size = new Size(196, 49);
            PasswordTb.TabIndex = 16;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Arial Unicode MS", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.FromArgb(0, 192, 0);
            label5.Location = new Point(937, 163);
            label5.Name = "label5";
            label5.Size = new Size(145, 40);
            label5.TabIndex = 15;
            label5.Text = "E-Mail Id";
            // 
            // EmailTb
            // 
            EmailTb.Font = new Font("Arial Unicode MS", 13.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            EmailTb.ForeColor = Color.Red;
            EmailTb.Location = new Point(885, 206);
            EmailTb.Multiline = true;
            EmailTb.Name = "EmailTb";
            EmailTb.PlaceholderText = "username@gmail.com";
            EmailTb.Size = new Size(323, 49);
            EmailTb.TabIndex = 14;
            EmailTb.TextChanged += EmailTb_TextChanged;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial Unicode MS", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.FromArgb(0, 192, 0);
            label4.Location = new Point(626, 163);
            label4.Name = "label4";
            label4.Size = new Size(197, 40);
            label4.TabIndex = 13;
            label4.Text = "Date of Birth";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial Unicode MS", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.FromArgb(0, 192, 0);
            label3.Location = new Point(383, 163);
            label3.Name = "label3";
            label3.Size = new Size(201, 40);
            label3.TabIndex = 11;
            label3.Text = "User Gender";
            // 
            // UNameTb
            // 
            UNameTb.Font = new Font("Arial Unicode MS", 13.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            UNameTb.ForeColor = Color.Red;
            UNameTb.Location = new Point(66, 206);
            UNameTb.Multiline = true;
            UNameTb.Name = "UNameTb";
            UNameTb.PlaceholderText = "Enter  Name";
            UNameTb.Size = new Size(255, 49);
            UNameTb.TabIndex = 10;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial Unicode MS", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.FromArgb(0, 192, 0);
            label2.Location = new Point(87, 163);
            label2.Name = "label2";
            label2.Size = new Size(179, 40);
            label2.TabIndex = 9;
            label2.Text = "User Name";
            // 
            // pictureBox9
            // 
            pictureBox9.Image = (Image)resources.GetObject("pictureBox9.Image");
            pictureBox9.Location = new Point(44, 12);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(73, 77);
            pictureBox9.TabIndex = 0;
            pictureBox9.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial Rounded MT Bold", 22.2F, FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Red;
            label1.Location = new Point(123, 46);
            label1.Name = "label1";
            label1.Size = new Size(276, 43);
            label1.TabIndex = 4;
            label1.Text = "Manage Users";
            // 
            // pictureBox16
            // 
            pictureBox16.Image = (Image)resources.GetObject("pictureBox16.Image");
            pictureBox16.Location = new Point(1749, 12);
            pictureBox16.Name = "pictureBox16";
            pictureBox16.Size = new Size(53, 58);
            pictureBox16.TabIndex = 2;
            pictureBox16.TabStop = false;
            pictureBox16.Click += pictureBox16_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(pictureBox10);
            panel1.Controls.Add(pictureBox11);
            panel1.Controls.Add(UserGDV);
            panel1.Controls.Add(label9);
            panel1.Controls.Add(DeleteBtn);
            panel1.Controls.Add(EditBtn);
            panel1.Controls.Add(SaveBtn);
            panel1.Controls.Add(UDOB);
            panel1.Controls.Add(GenCb);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(PhoneTb);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(PasswordTb);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(EmailTb);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(UNameTb);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(pictureBox16);
            panel1.Controls.Add(pictureBox9);
            panel1.Dock = DockStyle.Right;
            panel1.Font = new Font("Arial Rounded MT Bold", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            panel1.ForeColor = Color.Red;
            panel1.Location = new Point(65, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1836, 983);
            panel1.TabIndex = 11;
            panel1.Paint += panel1_Paint;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Red;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(1035, 335);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(30, 29);
            pictureBox1.TabIndex = 48;
            pictureBox1.TabStop = false;
            // 
            // pictureBox10
            // 
            pictureBox10.BackColor = Color.Black;
            pictureBox10.Image = (Image)resources.GetObject("pictureBox10.Image");
            pictureBox10.Location = new Point(739, 335);
            pictureBox10.Name = "pictureBox10";
            pictureBox10.Size = new Size(30, 29);
            pictureBox10.TabIndex = 47;
            pictureBox10.TabStop = false;
            // 
            // pictureBox11
            // 
            pictureBox11.BackColor = Color.Green;
            pictureBox11.Image = (Image)resources.GetObject("pictureBox11.Image");
            pictureBox11.Location = new Point(459, 335);
            pictureBox11.Name = "pictureBox11";
            pictureBox11.Size = new Size(25, 29);
            pictureBox11.TabIndex = 46;
            pictureBox11.TabStop = false;
            // 
            // UserGDV
            // 
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = Color.FromArgb(255, 128, 128);
            dataGridViewCellStyle1.Font = new Font("Arial", 16.2F, FontStyle.Italic, GraphicsUnit.Point, 0);
            dataGridViewCellStyle1.ForeColor = Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = Color.Red;
            dataGridViewCellStyle1.SelectionForeColor = Color.White;
            UserGDV.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            UserGDV.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            UserGDV.BackgroundColor = Color.White;
            UserGDV.BorderStyle = BorderStyle.None;
            UserGDV.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = Color.Red;
            dataGridViewCellStyle2.Font = new Font("Arial", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            dataGridViewCellStyle2.ForeColor = Color.White;
            dataGridViewCellStyle2.SelectionBackColor = Color.Red;
            dataGridViewCellStyle2.SelectionForeColor = Color.White;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            UserGDV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            UserGDV.ColumnHeadersHeight = 32;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = Color.FromArgb(255, 128, 128);
            dataGridViewCellStyle3.Font = new Font("Arial", 16.2F, FontStyle.Italic, GraphicsUnit.Point, 0);
            dataGridViewCellStyle3.ForeColor = Color.Red;
            dataGridViewCellStyle3.SelectionBackColor = Color.Red;
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            UserGDV.DefaultCellStyle = dataGridViewCellStyle3;
            UserGDV.GridColor = Color.Red;
            UserGDV.ImeMode = ImeMode.On;
            UserGDV.Location = new Point(44, 478);
            UserGDV.Name = "UserGDV";
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = Color.Red;
            dataGridViewCellStyle4.Font = new Font("Arial", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            dataGridViewCellStyle4.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = Color.Red;
            dataGridViewCellStyle4.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = DataGridViewTriState.True;
            UserGDV.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            UserGDV.RowHeadersWidth = 51;
            UserGDV.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            UserGDV.Size = new Size(1713, 493);
            UserGDV.TabIndex = 28;
            UserGDV.CellContentClick += UserGDV_CellContentClick;
            // 
            // pictureBox12
            // 
            pictureBox12.Image = (Image)resources.GetObject("pictureBox12.Image");
            pictureBox12.Location = new Point(1, 647);
            pictureBox12.Name = "pictureBox12";
            pictureBox12.Size = new Size(62, 64);
            pictureBox12.TabIndex = 59;
            pictureBox12.TabStop = false;
            pictureBox12.Click += pictureBox12_Click;
            // 
            // pictureBox13
            // 
            pictureBox13.Image = (Image)resources.GetObject("pictureBox13.Image");
            pictureBox13.Location = new Point(2, 739);
            pictureBox13.Name = "pictureBox13";
            pictureBox13.Size = new Size(62, 64);
            pictureBox13.TabIndex = 60;
            pictureBox13.TabStop = false;
            pictureBox13.Click += pictureBox13_Click;
            // 
            // Users
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(0, 192, 0);
            ClientSize = new Size(1901, 983);
            Controls.Add(pictureBox13);
            Controls.Add(pictureBox12);
            Controls.Add(panel1);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox8);
            Controls.Add(pictureBox6);
            Controls.Add(pictureBox7);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox5);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Users";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Users";
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox16).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).EndInit();
            ((System.ComponentModel.ISupportInitialize)UserGDV).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private PictureBox pictureBox3;
        private PictureBox pictureBox8;
        private PictureBox pictureBox7;
        private PictureBox pictureBox6;
        private PictureBox pictureBox5;
        private PictureBox pictureBox4;
        private PictureBox pictureBox2;
        private Label label9;
        private Button DeleteBtn;
        private Button EditBtn;
        private Button SaveBtn;
        private DateTimePicker UDOB;
        private ComboBox GenCb;
        private Label label7;
        private TextBox PhoneTb;
        private Label label6;
        private TextBox PasswordTb;
        private Label label5;
        private TextBox EmailTb;
        private Label label4;
        private Label label3;
        private TextBox UNameTb;
        private Label label2;
        private PictureBox pictureBox9;
        private Label label1;
        private PictureBox pictureBox16;
        private Panel panel1;
        private DataGridView UserGDV;
        private PictureBox pictureBox1;
        private PictureBox pictureBox10;
        private PictureBox pictureBox11;
        private PictureBox pictureBox12;
        private PictureBox pictureBox13;
    }
}