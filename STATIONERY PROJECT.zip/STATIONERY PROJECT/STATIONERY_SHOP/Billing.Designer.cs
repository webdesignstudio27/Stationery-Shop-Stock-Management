﻿namespace STATIONERY_SHOP
{
    partial class Billing
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Billing));
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle6 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle7 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle8 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle9 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle10 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle11 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle12 = new DataGridViewCellStyle();
            pictureBox8 = new PictureBox();
            pictureBox7 = new PictureBox();
            pictureBox6 = new PictureBox();
            pictureBox5 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox2 = new PictureBox();
            panel1 = new Panel();
            RefreshImg = new PictureBox();
            SearchImg = new PictureBox();
            SearchTb = new TextBox();
            PhoneTb = new TextBox();
            label10 = new Label();
            pictureBox11 = new PictureBox();
            pictureBox10 = new PictureBox();
            pictureBox1 = new PictureBox();
            ULabel = new Label();
            GrdTotalLbl = new Label();
            ClientBillDGV = new DataGridView();
            Column1 = new DataGridViewTextBoxColumn();
            Column2 = new DataGridViewTextBoxColumn();
            Column3 = new DataGridViewTextBoxColumn();
            Column4 = new DataGridViewTextBoxColumn();
            Column5 = new DataGridViewTextBoxColumn();
            ProdNameTb = new TextBox();
            label7 = new Label();
            BillsDGV = new DataGridView();
            ItemsDGV = new DataGridView();
            label5 = new Label();
            label3 = new Label();
            label9 = new Label();
            PrintBtn = new Button();
            RefreshBtn = new Button();
            AddToBillBtn = new Button();
            label6 = new Label();
            PriceTb = new TextBox();
            BillDate = new DateTimePicker();
            label8 = new Label();
            label4 = new Label();
            QuantityTb = new TextBox();
            BCustomer = new TextBox();
            label2 = new Label();
            label1 = new Label();
            pictureBox16 = new PictureBox();
            pictureBox9 = new PictureBox();
            printDocument1 = new System.Drawing.Printing.PrintDocument();
            printPreviewDialog1 = new PrintPreviewDialog();
            pictureBox12 = new PictureBox();
            pictureBox13 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)RefreshImg).BeginInit();
            ((System.ComponentModel.ISupportInitialize)SearchImg).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)ClientBillDGV).BeginInit();
            ((System.ComponentModel.ISupportInitialize)BillsDGV).BeginInit();
            ((System.ComponentModel.ISupportInitialize)ItemsDGV).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox16).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).BeginInit();
            SuspendLayout();
            // 
            // pictureBox8
            // 
            pictureBox8.Image = (Image)resources.GetObject("pictureBox8.Image");
            pictureBox8.Location = new Point(6, 883);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(53, 58);
            pictureBox8.TabIndex = 5;
            pictureBox8.TabStop = false;
            pictureBox8.Click += pictureBox8_Click;
            // 
            // pictureBox7
            // 
            pictureBox7.Image = (Image)resources.GetObject("pictureBox7.Image");
            pictureBox7.Location = new Point(3, 540);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(53, 58);
            pictureBox7.TabIndex = 6;
            pictureBox7.TabStop = false;
            pictureBox7.Click += pictureBox7_Click;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = (Image)resources.GetObject("pictureBox6.Image");
            pictureBox6.Location = new Point(3, 446);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(53, 58);
            pictureBox6.TabIndex = 7;
            pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(2, 354);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(53, 58);
            pictureBox5.TabIndex = 8;
            pictureBox5.TabStop = false;
            pictureBox5.Click += pictureBox5_Click;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(6, 263);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(53, 58);
            pictureBox4.TabIndex = 9;
            pictureBox4.TabStop = false;
            pictureBox4.Click += pictureBox4_Click;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(6, 163);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(53, 58);
            pictureBox3.TabIndex = 10;
            pictureBox3.TabStop = false;
            pictureBox3.Click += pictureBox3_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(6, 12);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(53, 58);
            pictureBox2.TabIndex = 4;
            pictureBox2.TabStop = false;
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.Controls.Add(RefreshImg);
            panel1.Controls.Add(SearchImg);
            panel1.Controls.Add(SearchTb);
            panel1.Controls.Add(PhoneTb);
            panel1.Controls.Add(label10);
            panel1.Controls.Add(pictureBox11);
            panel1.Controls.Add(pictureBox10);
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(ULabel);
            panel1.Controls.Add(GrdTotalLbl);
            panel1.Controls.Add(ClientBillDGV);
            panel1.Controls.Add(ProdNameTb);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(BillsDGV);
            panel1.Controls.Add(ItemsDGV);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label9);
            panel1.Controls.Add(PrintBtn);
            panel1.Controls.Add(RefreshBtn);
            panel1.Controls.Add(AddToBillBtn);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(PriceTb);
            panel1.Controls.Add(BillDate);
            panel1.Controls.Add(label8);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(QuantityTb);
            panel1.Controls.Add(BCustomer);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(pictureBox16);
            panel1.Controls.Add(pictureBox9);
            panel1.Dock = DockStyle.Right;
            panel1.Location = new Point(65, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1836, 983);
            panel1.TabIndex = 3;
            panel1.Paint += panel1_Paint;
            // 
            // RefreshImg
            // 
            RefreshImg.Image = (Image)resources.GetObject("RefreshImg.Image");
            RefreshImg.Location = new Point(386, 419);
            RefreshImg.Name = "RefreshImg";
            RefreshImg.Size = new Size(57, 52);
            RefreshImg.TabIndex = 68;
            RefreshImg.TabStop = false;
            RefreshImg.Click += RefreshImg_Click;
            // 
            // SearchImg
            // 
            SearchImg.Image = (Image)resources.GetObject("SearchImg.Image");
            SearchImg.Location = new Point(313, 419);
            SearchImg.Name = "SearchImg";
            SearchImg.Size = new Size(57, 52);
            SearchImg.TabIndex = 67;
            SearchImg.TabStop = false;
            SearchImg.Click += SearchImg_Click;
            // 
            // SearchTb
            // 
            SearchTb.Font = new Font("Arial Unicode MS", 13.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            SearchTb.ForeColor = Color.Red;
            SearchTb.Location = new Point(59, 430);
            SearchTb.Multiline = true;
            SearchTb.Name = "SearchTb";
            SearchTb.PlaceholderText = "Search Item";
            SearchTb.Size = new Size(245, 39);
            SearchTb.TabIndex = 66;
            // 
            // PhoneTb
            // 
            PhoneTb.Font = new Font("Arial Unicode MS", 13.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            PhoneTb.ForeColor = Color.Red;
            PhoneTb.Location = new Point(314, 172);
            PhoneTb.Multiline = true;
            PhoneTb.Name = "PhoneTb";
            PhoneTb.PlaceholderText = "Phone Number";
            PhoneTb.Size = new Size(196, 49);
            PhoneTb.TabIndex = 45;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Arial Unicode MS", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label10.ForeColor = Color.FromArgb(0, 192, 0);
            label10.Location = new Point(303, 124);
            label10.Name = "label10";
            label10.Size = new Size(233, 40);
            label10.TabIndex = 44;
            label10.Text = "Phone Number";
            // 
            // pictureBox11
            // 
            pictureBox11.BackColor = Color.Black;
            pictureBox11.Image = (Image)resources.GetObject("pictureBox11.Image");
            pictureBox11.Location = new Point(326, 360);
            pictureBox11.Name = "pictureBox11";
            pictureBox11.Size = new Size(30, 29);
            pictureBox11.TabIndex = 43;
            pictureBox11.TabStop = false;
            // 
            // pictureBox10
            // 
            pictureBox10.BackColor = Color.Green;
            pictureBox10.Image = (Image)resources.GetObject("pictureBox10.Image");
            pictureBox10.Location = new Point(59, 360);
            pictureBox10.Name = "pictureBox10";
            pictureBox10.Size = new Size(30, 29);
            pictureBox10.TabIndex = 42;
            pictureBox10.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(1371, 386);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(57, 46);
            pictureBox1.TabIndex = 41;
            pictureBox1.TabStop = false;
            // 
            // ULabel
            // 
            ULabel.AutoSize = true;
            ULabel.Font = new Font("Arial Unicode MS", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ULabel.ForeColor = SystemColors.MenuHighlight;
            ULabel.Location = new Point(763, 914);
            ULabel.Name = "ULabel";
            ULabel.Size = new Size(108, 31);
            ULabel.TabIndex = 40;
            ULabel.Text = "Total Rs";
            // 
            // GrdTotalLbl
            // 
            GrdTotalLbl.AutoSize = true;
            GrdTotalLbl.Font = new Font("Arial Unicode MS", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            GrdTotalLbl.ForeColor = Color.FromArgb(0, 192, 0);
            GrdTotalLbl.Location = new Point(997, 392);
            GrdTotalLbl.Name = "GrdTotalLbl";
            GrdTotalLbl.Size = new Size(137, 40);
            GrdTotalLbl.TabIndex = 39;
            GrdTotalLbl.Text = "Total Rs";
            GrdTotalLbl.Click += GrdTotalLbl_Click;
            // 
            // ClientBillDGV
            // 
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = Color.White;
            dataGridViewCellStyle1.Font = new Font("Arial", 13.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            dataGridViewCellStyle1.ForeColor = Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = Color.FromArgb(0, 192, 0);
            dataGridViewCellStyle1.SelectionForeColor = Color.White;
            ClientBillDGV.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            ClientBillDGV.BackgroundColor = Color.White;
            ClientBillDGV.BorderStyle = BorderStyle.None;
            ClientBillDGV.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = Color.Red;
            dataGridViewCellStyle2.Font = new Font("Arial", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            dataGridViewCellStyle2.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = Color.Red;
            dataGridViewCellStyle2.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            ClientBillDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            ClientBillDGV.ColumnHeadersHeight = 30;
            ClientBillDGV.Columns.AddRange(new DataGridViewColumn[] { Column1, Column2, Column3, Column4, Column5 });
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = Color.White;
            dataGridViewCellStyle3.Font = new Font("Arial", 13.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            dataGridViewCellStyle3.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = Color.FromArgb(0, 192, 0);
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            ClientBillDGV.DefaultCellStyle = dataGridViewCellStyle3;
            ClientBillDGV.GridColor = Color.Silver;
            ClientBillDGV.Location = new Point(919, 73);
            ClientBillDGV.Name = "ClientBillDGV";
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle4.BackColor = Color.Red;
            dataGridViewCellStyle4.Font = new Font("Arial", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle4.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = Color.Red;
            dataGridViewCellStyle4.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = DataGridViewTriState.True;
            ClientBillDGV.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            ClientBillDGV.RowHeadersWidth = 51;
            ClientBillDGV.RowTemplate.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            ClientBillDGV.RowTemplate.DefaultCellStyle.BackColor = Color.White;
            ClientBillDGV.RowTemplate.DefaultCellStyle.Font = new Font("Arial", 13.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            ClientBillDGV.RowTemplate.DefaultCellStyle.ForeColor = Color.Black;
            ClientBillDGV.RowTemplate.DefaultCellStyle.SelectionBackColor = Color.FromArgb(0, 192, 0);
            ClientBillDGV.RowTemplate.Height = 30;
            ClientBillDGV.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            ClientBillDGV.Size = new Size(852, 307);
            ClientBillDGV.TabIndex = 38;
            // 
            // Column1
            // 
            Column1.HeaderText = "ID";
            Column1.MinimumWidth = 6;
            Column1.Name = "Column1";
            Column1.Width = 132;
            // 
            // Column2
            // 
            Column2.HeaderText = "Product";
            Column2.MinimumWidth = 6;
            Column2.Name = "Column2";
            Column2.Width = 132;
            // 
            // Column3
            // 
            Column3.HeaderText = "Price";
            Column3.MinimumWidth = 6;
            Column3.Name = "Column3";
            Column3.Width = 131;
            // 
            // Column4
            // 
            Column4.HeaderText = "Quantity";
            Column4.MinimumWidth = 6;
            Column4.Name = "Column4";
            Column4.Width = 132;
            // 
            // Column5
            // 
            Column5.HeaderText = "Total";
            Column5.MinimumWidth = 6;
            Column5.Name = "Column5";
            Column5.Width = 132;
            // 
            // ProdNameTb
            // 
            ProdNameTb.Enabled = false;
            ProdNameTb.Font = new Font("Arial Unicode MS", 13.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            ProdNameTb.ForeColor = Color.Red;
            ProdNameTb.Location = new Point(561, 172);
            ProdNameTb.Multiline = true;
            ProdNameTb.Name = "ProdNameTb";
            ProdNameTb.PlaceholderText = "Enter  Product";
            ProdNameTb.Size = new Size(290, 49);
            ProdNameTb.TabIndex = 37;
            ProdNameTb.TextChanged += ProdNameTb_TextChanged;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Arial Unicode MS", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.FromArgb(0, 192, 0);
            label7.Location = new Point(590, 124);
            label7.Name = "label7";
            label7.Size = new Size(222, 40);
            label7.TabIndex = 36;
            label7.Text = "Product Name";
            // 
            // BillsDGV
            // 
            dataGridViewCellStyle5.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = Color.FromArgb(255, 255, 192);
            dataGridViewCellStyle5.Font = new Font("Arial Narrow", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            dataGridViewCellStyle5.ForeColor = Color.Black;
            dataGridViewCellStyle5.SelectionBackColor = Color.Yellow;
            dataGridViewCellStyle5.SelectionForeColor = Color.FromArgb(0, 192, 0);
            BillsDGV.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            BillsDGV.BackgroundColor = Color.White;
            BillsDGV.BorderStyle = BorderStyle.None;
            BillsDGV.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle6.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = Color.FromArgb(255, 255, 192);
            dataGridViewCellStyle6.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            dataGridViewCellStyle6.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = Color.Yellow;
            dataGridViewCellStyle6.SelectionForeColor = Color.FromArgb(0, 192, 0);
            dataGridViewCellStyle6.WrapMode = DataGridViewTriState.True;
            BillsDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            BillsDGV.ColumnHeadersHeight = 32;
            dataGridViewCellStyle7.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.BackColor = Color.FromArgb(255, 255, 192);
            dataGridViewCellStyle7.Font = new Font("Arial Narrow", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            dataGridViewCellStyle7.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle7.SelectionBackColor = Color.Yellow;
            dataGridViewCellStyle7.SelectionForeColor = Color.FromArgb(0, 192, 0);
            dataGridViewCellStyle7.WrapMode = DataGridViewTriState.False;
            BillsDGV.DefaultCellStyle = dataGridViewCellStyle7;
            BillsDGV.Location = new Point(919, 502);
            BillsDGV.Name = "BillsDGV";
            dataGridViewCellStyle8.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle8.BackColor = SystemColors.Control;
            dataGridViewCellStyle8.Font = new Font("Arial", 10.8F, FontStyle.Bold);
            dataGridViewCellStyle8.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle8.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = DataGridViewTriState.True;
            BillsDGV.RowHeadersDefaultCellStyle = dataGridViewCellStyle8;
            BillsDGV.RowHeadersWidth = 51;
            BillsDGV.Size = new Size(852, 439);
            BillsDGV.TabIndex = 35;
            BillsDGV.CellContentClick += BillsDGV_CellContentClick;
            // 
            // ItemsDGV
            // 
            dataGridViewCellStyle9.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle9.BackColor = Color.White;
            dataGridViewCellStyle9.Font = new Font("Arial", 13.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            dataGridViewCellStyle9.ForeColor = Color.Black;
            dataGridViewCellStyle9.SelectionBackColor = Color.Red;
            dataGridViewCellStyle9.SelectionForeColor = Color.White;
            ItemsDGV.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle9;
            ItemsDGV.BackgroundColor = Color.White;
            ItemsDGV.BorderStyle = BorderStyle.None;
            dataGridViewCellStyle10.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle10.BackColor = Color.Red;
            dataGridViewCellStyle10.Font = new Font("Arial", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            dataGridViewCellStyle10.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle10.SelectionBackColor = Color.Red;
            dataGridViewCellStyle10.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = DataGridViewTriState.True;
            ItemsDGV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            ItemsDGV.ColumnHeadersHeight = 30;
            dataGridViewCellStyle11.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle11.BackColor = Color.White;
            dataGridViewCellStyle11.Font = new Font("Arial", 13.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            dataGridViewCellStyle11.ForeColor = SystemColors.ControlText;
            dataGridViewCellStyle11.SelectionBackColor = Color.Red;
            dataGridViewCellStyle11.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = DataGridViewTriState.False;
            ItemsDGV.DefaultCellStyle = dataGridViewCellStyle11;
            ItemsDGV.GridColor = Color.White;
            ItemsDGV.Location = new Point(46, 540);
            ItemsDGV.Name = "ItemsDGV";
            dataGridViewCellStyle12.Alignment = DataGridViewContentAlignment.TopCenter;
            dataGridViewCellStyle12.BackColor = Color.Red;
            dataGridViewCellStyle12.Font = new Font("Arial", 10.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle12.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle12.SelectionBackColor = Color.Red;
            dataGridViewCellStyle12.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = DataGridViewTriState.True;
            ItemsDGV.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            ItemsDGV.RowHeadersWidth = 51;
            ItemsDGV.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            ItemsDGV.Size = new Size(711, 401);
            ItemsDGV.TabIndex = 33;
            ItemsDGV.CellContentClick += ItemsDGV_CellContentClick;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Arial Unicode MS", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.FromArgb(0, 192, 0);
            label5.Location = new Point(1193, 30);
            label5.Name = "label5";
            label5.Size = new Size(155, 40);
            label5.TabIndex = 32;
            label5.Text = "Client Bill";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial Unicode MS", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.FromArgb(0, 192, 0);
            label3.Location = new Point(1193, 447);
            label3.Name = "label3";
            label3.Size = new Size(158, 40);
            label3.TabIndex = 31;
            label3.Text = "Sales List";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Arial Unicode MS", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.FromArgb(0, 192, 0);
            label9.Location = new Point(303, 474);
            label9.Name = "label9";
            label9.Size = new Size(155, 40);
            label9.TabIndex = 30;
            label9.Text = "Items List";
            // 
            // PrintBtn
            // 
            PrintBtn.BackColor = Color.Red;
            PrintBtn.Font = new Font("Arial Unicode MS", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            PrintBtn.ForeColor = Color.White;
            PrintBtn.Location = new Point(1193, 386);
            PrintBtn.Name = "PrintBtn";
            PrintBtn.Size = new Size(172, 58);
            PrintBtn.TabIndex = 29;
            PrintBtn.Text = "Print Bill";
            PrintBtn.UseVisualStyleBackColor = false;
            PrintBtn.Click += PrintBtn_Click;
            // 
            // RefreshBtn
            // 
            RefreshBtn.BackColor = Color.Black;
            RefreshBtn.Font = new Font("Arial Unicode MS", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            RefreshBtn.ForeColor = Color.White;
            RefreshBtn.Location = new Point(314, 344);
            RefreshBtn.Name = "RefreshBtn";
            RefreshBtn.Size = new Size(208, 58);
            RefreshBtn.TabIndex = 28;
            RefreshBtn.Text = "Refresh";
            RefreshBtn.UseVisualStyleBackColor = false;
            RefreshBtn.Click += RefreshBtn_Click;
            // 
            // AddToBillBtn
            // 
            AddToBillBtn.BackColor = Color.Green;
            AddToBillBtn.Font = new Font("Arial Unicode MS", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            AddToBillBtn.ForeColor = Color.White;
            AddToBillBtn.Location = new Point(49, 344);
            AddToBillBtn.Name = "AddToBillBtn";
            AddToBillBtn.Size = new Size(238, 58);
            AddToBillBtn.TabIndex = 27;
            AddToBillBtn.Text = "Add to Bill";
            AddToBillBtn.UseVisualStyleBackColor = false;
            AddToBillBtn.Click += AddToBillBtn_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Arial Unicode MS", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.FromArgb(0, 192, 0);
            label6.Location = new Point(386, 242);
            label6.Name = "label6";
            label6.Size = new Size(91, 40);
            label6.TabIndex = 26;
            label6.Text = "Price";
            // 
            // PriceTb
            // 
            PriceTb.Enabled = false;
            PriceTb.Font = new Font("Arial Unicode MS", 13.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            PriceTb.ForeColor = Color.Red;
            PriceTb.Location = new Point(386, 285);
            PriceTb.Multiline = true;
            PriceTb.Name = "PriceTb";
            PriceTb.PlaceholderText = "Enter  Price";
            PriceTb.Size = new Size(136, 49);
            PriceTb.TabIndex = 25;
            // 
            // BillDate
            // 
            BillDate.CalendarForeColor = Color.Red;
            BillDate.CalendarTrailingForeColor = Color.Red;
            BillDate.Font = new Font("Arial Rounded MT Bold", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            BillDate.Location = new Point(46, 282);
            BillDate.Name = "BillDate";
            BillDate.RightToLeft = RightToLeft.Yes;
            BillDate.RightToLeftLayout = true;
            BillDate.Size = new Size(242, 31);
            BillDate.TabIndex = 24;
            BillDate.ValueChanged += BillDate_ValueChanged;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Arial Unicode MS", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.FromArgb(0, 192, 0);
            label8.Location = new Point(46, 239);
            label8.Name = "label8";
            label8.Size = new Size(165, 40);
            label8.TabIndex = 23;
            label8.Text = "Billid Date";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial Unicode MS", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.FromArgb(0, 192, 0);
            label4.Location = new Point(533, 239);
            label4.Name = "label4";
            label4.Size = new Size(137, 40);
            label4.TabIndex = 15;
            label4.Text = "Quantity";
            // 
            // QuantityTb
            // 
            QuantityTb.Font = new Font("Arial Unicode MS", 13.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            QuantityTb.ForeColor = Color.Red;
            QuantityTb.Location = new Point(542, 290);
            QuantityTb.Multiline = true;
            QuantityTb.Name = "QuantityTb";
            QuantityTb.PlaceholderText = "Enter  Quantity";
            QuantityTb.Size = new Size(168, 44);
            QuantityTb.TabIndex = 14;
            // 
            // BCustomer
            // 
            BCustomer.Font = new Font("Arial Unicode MS", 13.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            BCustomer.ForeColor = Color.Red;
            BCustomer.Location = new Point(46, 172);
            BCustomer.Multiline = true;
            BCustomer.Name = "BCustomer";
            BCustomer.PlaceholderText = "Enter  Name";
            BCustomer.Size = new Size(242, 49);
            BCustomer.TabIndex = 12;
            BCustomer.TextChanged += BCustomer_TextChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial Unicode MS", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.FromArgb(0, 192, 0);
            label2.Location = new Point(37, 124);
            label2.Name = "label2";
            label2.Size = new Size(250, 40);
            label2.TabIndex = 11;
            label2.Text = "Customer Name";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial Rounded MT Bold", 22.2F, FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Red;
            label1.Location = new Point(125, 48);
            label1.Name = "label1";
            label1.Size = new Size(131, 43);
            label1.TabIndex = 7;
            label1.Text = "Billing";
            // 
            // pictureBox16
            // 
            pictureBox16.Image = (Image)resources.GetObject("pictureBox16.Image");
            pictureBox16.Location = new Point(1751, 14);
            pictureBox16.Name = "pictureBox16";
            pictureBox16.Size = new Size(53, 58);
            pictureBox16.TabIndex = 6;
            pictureBox16.TabStop = false;
            pictureBox16.Click += pictureBox16_Click;
            // 
            // pictureBox9
            // 
            pictureBox9.Image = (Image)resources.GetObject("pictureBox9.Image");
            pictureBox9.Location = new Point(46, 14);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(73, 77);
            pictureBox9.TabIndex = 5;
            pictureBox9.TabStop = false;
            // 
            // printDocument1
            // 
            printDocument1.PrintPage += printDocument1_PrintPage;
            // 
            // printPreviewDialog1
            // 
            printPreviewDialog1.AutoScrollMargin = new Size(0, 0);
            printPreviewDialog1.AutoScrollMinSize = new Size(0, 0);
            printPreviewDialog1.ClientSize = new Size(400, 300);
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.Enabled = true;
            printPreviewDialog1.Icon = (Icon)resources.GetObject("printPreviewDialog1.Icon");
            printPreviewDialog1.Name = "printPreviewDialog1";
            printPreviewDialog1.Visible = false;
            // 
            // pictureBox12
            // 
            pictureBox12.Image = (Image)resources.GetObject("pictureBox12.Image");
            pictureBox12.Location = new Point(1, 647);
            pictureBox12.Name = "pictureBox12";
            pictureBox12.Size = new Size(62, 64);
            pictureBox12.TabIndex = 59;
            pictureBox12.TabStop = false;
            pictureBox12.Click += pictureBox12_Click;
            // 
            // pictureBox13
            // 
            pictureBox13.Image = (Image)resources.GetObject("pictureBox13.Image");
            pictureBox13.Location = new Point(2, 739);
            pictureBox13.Name = "pictureBox13";
            pictureBox13.Size = new Size(53, 58);
            pictureBox13.TabIndex = 44;
            pictureBox13.TabStop = false;
            pictureBox13.Click += pictureBox13_Click;
            // 
            // Billing
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(0, 192, 0);
            ClientSize = new Size(1901, 983);
            Controls.Add(pictureBox13);
            Controls.Add(pictureBox12);
            Controls.Add(panel1);
            Controls.Add(pictureBox8);
            Controls.Add(pictureBox7);
            Controls.Add(pictureBox6);
            Controls.Add(pictureBox5);
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox2);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Billing";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Billing";
            Load += Billing_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)RefreshImg).EndInit();
            ((System.ComponentModel.ISupportInitialize)SearchImg).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)ClientBillDGV).EndInit();
            ((System.ComponentModel.ISupportInitialize)BillsDGV).EndInit();
            ((System.ComponentModel.ISupportInitialize)ItemsDGV).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox16).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private PictureBox pictureBox8;
        private PictureBox pictureBox7;
        private PictureBox pictureBox6;
        private PictureBox pictureBox5;
        private PictureBox pictureBox4;
        private PictureBox pictureBox3;
        private PictureBox pictureBox2;
        private Panel panel1;
        private Label label1;
        private PictureBox pictureBox16;
        private PictureBox pictureBox9;
        private TextBox BCustomer;
        private Label label2;
        private Label label4;
        private TextBox QuantityTb;
        private DateTimePicker BillDate;
        private Label label8;
        private Label label6;
        private TextBox PriceTb;
        private Label label3;
        private Label label9;
        private Button PrintBtn;
        private Button RefreshBtn;
        private Button AddToBillBtn;
        private Label label5;
        private DataGridView ItemsDGV;
        private DataGridView BillsDGV;
        private TextBox ProdNameTb;
        private Label label7;
        private DataGridView ClientBillDGV;
        private DataGridViewTextBoxColumn Column1;
        private DataGridViewTextBoxColumn Column2;
        private DataGridViewTextBoxColumn Column3;
        private DataGridViewTextBoxColumn Column4;
        private DataGridViewTextBoxColumn Column5;
        private Label GrdTotalLbl;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private PrintPreviewDialog printPreviewDialog1;
        private Label ULabel;
        private PictureBox pictureBox1;
        private PictureBox pictureBox11;
        private PictureBox pictureBox10;
        private PictureBox pictureBox12;
        private PictureBox pictureBox13;
        private Label label10;
        private TextBox PhoneTb;
        private PictureBox RefreshImg;
        private PictureBox SearchImg;
        private TextBox SearchTb;
    }
}