﻿namespace STATIONERY_SHOP
{
    partial class Items
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Items));
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            panel1 = new Panel();
            pictureBox10 = new PictureBox();
            pictureBox11 = new PictureBox();
            pictureBox12 = new PictureBox();
            RefreshImg = new PictureBox();
            SearchImg = new PictureBox();
            SearchTb = new TextBox();
            ProductGDV = new DataGridView();
            label9 = new Label();
            DeleteBtn = new Button();
            EditBtn = new Button();
            SaveBtn = new Button();
            ProdDate = new DateTimePicker();
            CatCb = new ComboBox();
            label8 = new Label();
            label7 = new Label();
            ProdDetailsTb = new TextBox();
            label6 = new Label();
            SPriceTb = new TextBox();
            label5 = new Label();
            BPriceTb = new TextBox();
            label4 = new Label();
            QuantityTb = new TextBox();
            label3 = new Label();
            ProdNameTb = new TextBox();
            label2 = new Label();
            label1 = new Label();
            pictureBox9 = new PictureBox();
            pictureBox1 = new PictureBox();
            pictureBox2 = new PictureBox();
            pictureBox3 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox5 = new PictureBox();
            pictureBox6 = new PictureBox();
            pictureBox7 = new PictureBox();
            pictureBox8 = new PictureBox();
            pictureBox13 = new PictureBox();
            pictureBox14 = new PictureBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).BeginInit();
            ((System.ComponentModel.ISupportInitialize)RefreshImg).BeginInit();
            ((System.ComponentModel.ISupportInitialize)SearchImg).BeginInit();
            ((System.ComponentModel.ISupportInitialize)ProductGDV).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox14).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.White;
            panel1.Controls.Add(pictureBox10);
            panel1.Controls.Add(pictureBox11);
            panel1.Controls.Add(pictureBox12);
            panel1.Controls.Add(RefreshImg);
            panel1.Controls.Add(SearchImg);
            panel1.Controls.Add(SearchTb);
            panel1.Controls.Add(ProductGDV);
            panel1.Controls.Add(label9);
            panel1.Controls.Add(DeleteBtn);
            panel1.Controls.Add(EditBtn);
            panel1.Controls.Add(SaveBtn);
            panel1.Controls.Add(ProdDate);
            panel1.Controls.Add(CatCb);
            panel1.Controls.Add(label8);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(ProdDetailsTb);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(SPriceTb);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(BPriceTb);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(QuantityTb);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(ProdNameTb);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(pictureBox9);
            panel1.Controls.Add(pictureBox1);
            panel1.Dock = DockStyle.Right;
            panel1.Font = new Font("Arial Rounded MT Bold", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            panel1.ForeColor = Color.Red;
            panel1.Location = new Point(62, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(1839, 983);
            panel1.TabIndex = 0;
            panel1.Paint += panel1_Paint_1;
            // 
            // pictureBox10
            // 
            pictureBox10.BackColor = Color.Red;
            pictureBox10.Image = (Image)resources.GetObject("pictureBox10.Image");
            pictureBox10.Location = new Point(1007, 332);
            pictureBox10.Name = "pictureBox10";
            pictureBox10.Size = new Size(26, 29);
            pictureBox10.TabIndex = 57;
            pictureBox10.TabStop = false;
            // 
            // pictureBox11
            // 
            pictureBox11.BackColor = Color.Black;
            pictureBox11.Image = (Image)resources.GetObject("pictureBox11.Image");
            pictureBox11.Location = new Point(724, 332);
            pictureBox11.Name = "pictureBox11";
            pictureBox11.Size = new Size(30, 29);
            pictureBox11.TabIndex = 56;
            pictureBox11.TabStop = false;
            // 
            // pictureBox12
            // 
            pictureBox12.BackColor = Color.Green;
            pictureBox12.Image = (Image)resources.GetObject("pictureBox12.Image");
            pictureBox12.Location = new Point(468, 332);
            pictureBox12.Name = "pictureBox12";
            pictureBox12.Size = new Size(25, 29);
            pictureBox12.TabIndex = 55;
            pictureBox12.TabStop = false;
            // 
            // RefreshImg
            // 
            RefreshImg.Image = (Image)resources.GetObject("RefreshImg.Image");
            RefreshImg.Location = new Point(309, 447);
            RefreshImg.Name = "RefreshImg";
            RefreshImg.Size = new Size(57, 52);
            RefreshImg.TabIndex = 54;
            RefreshImg.TabStop = false;
            RefreshImg.Click += RefreshImg_Click;
            // 
            // SearchImg
            // 
            SearchImg.Image = (Image)resources.GetObject("SearchImg.Image");
            SearchImg.Location = new Point(246, 447);
            SearchImg.Name = "SearchImg";
            SearchImg.Size = new Size(57, 52);
            SearchImg.TabIndex = 53;
            SearchImg.TabStop = false;
            SearchImg.Click += pictureBox10_Click;
            // 
            // SearchTb
            // 
            SearchTb.Font = new Font("Arial Unicode MS", 13.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            SearchTb.ForeColor = Color.Red;
            SearchTb.Location = new Point(44, 447);
            SearchTb.Multiline = true;
            SearchTb.Name = "SearchTb";
            SearchTb.PlaceholderText = "Search Item";
            SearchTb.Size = new Size(196, 49);
            SearchTb.TabIndex = 52;
            SearchTb.TextChanged += SearchTb_TextChanged;
            // 
            // ProductGDV
            // 
            dataGridViewCellStyle1.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = Color.FromArgb(255, 192, 192);
            dataGridViewCellStyle1.Font = new Font("Arial", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            dataGridViewCellStyle1.ForeColor = Color.Black;
            dataGridViewCellStyle1.SelectionBackColor = Color.Red;
            dataGridViewCellStyle1.SelectionForeColor = Color.White;
            ProductGDV.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            ProductGDV.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            ProductGDV.BackgroundColor = Color.White;
            ProductGDV.BorderStyle = BorderStyle.None;
            ProductGDV.ColumnHeadersBorderStyle = DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = Color.Red;
            dataGridViewCellStyle2.Font = new Font("Arial", 12F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            dataGridViewCellStyle2.ForeColor = Color.White;
            dataGridViewCellStyle2.SelectionBackColor = Color.Red;
            dataGridViewCellStyle2.SelectionForeColor = Color.White;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            ProductGDV.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            ProductGDV.ColumnHeadersHeight = 45;
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = Color.FromArgb(255, 128, 128);
            dataGridViewCellStyle3.Font = new Font("Arial", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            dataGridViewCellStyle3.ForeColor = Color.Red;
            dataGridViewCellStyle3.SelectionBackColor = Color.Red;
            dataGridViewCellStyle3.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = DataGridViewTriState.False;
            ProductGDV.DefaultCellStyle = dataGridViewCellStyle3;
            ProductGDV.GridColor = Color.Red;
            ProductGDV.ImeMode = ImeMode.On;
            ProductGDV.Location = new Point(26, 541);
            ProductGDV.Name = "ProductGDV";
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = Color.FromArgb(255, 128, 128);
            dataGridViewCellStyle4.Font = new Font("Arial Narrow", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            dataGridViewCellStyle4.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = Color.Red;
            dataGridViewCellStyle4.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = DataGridViewTriState.True;
            ProductGDV.RowHeadersDefaultCellStyle = dataGridViewCellStyle4;
            ProductGDV.RowHeadersWidth = 70;
            ProductGDV.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            ProductGDV.Size = new Size(1745, 411);
            ProductGDV.TabIndex = 50;
            ProductGDV.CellContentClick += ProductGDV_CellContentClick;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Arial Unicode MS", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.FromArgb(0, 192, 0);
            label9.Location = new Point(748, 452);
            label9.Name = "label9";
            label9.Size = new Size(220, 40);
            label9.TabIndex = 26;
            label9.Text = "Manage Items";
            // 
            // DeleteBtn
            // 
            DeleteBtn.BackColor = Color.Red;
            DeleteBtn.Font = new Font("Arial Unicode MS", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            DeleteBtn.ForeColor = Color.White;
            DeleteBtn.Location = new Point(997, 318);
            DeleteBtn.Name = "DeleteBtn";
            DeleteBtn.Size = new Size(283, 58);
            DeleteBtn.TabIndex = 25;
            DeleteBtn.Text = "DELETE ITEM";
            DeleteBtn.UseVisualStyleBackColor = false;
            DeleteBtn.Click += DeleteBtn_Click;
            // 
            // EditBtn
            // 
            EditBtn.BackColor = Color.Black;
            EditBtn.Font = new Font("Arial Unicode MS", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            EditBtn.ForeColor = Color.White;
            EditBtn.Location = new Point(719, 318);
            EditBtn.Name = "EditBtn";
            EditBtn.Size = new Size(229, 58);
            EditBtn.TabIndex = 24;
            EditBtn.Text = "EDIT ITEM";
            EditBtn.UseVisualStyleBackColor = false;
            EditBtn.Click += EditBtn_Click_1;
            // 
            // SaveBtn
            // 
            SaveBtn.BackColor = Color.Green;
            SaveBtn.Font = new Font("Arial Unicode MS", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            SaveBtn.ForeColor = Color.White;
            SaveBtn.Location = new Point(456, 318);
            SaveBtn.Name = "SaveBtn";
            SaveBtn.Size = new Size(244, 58);
            SaveBtn.TabIndex = 23;
            SaveBtn.Text = "SAVE ITEM";
            SaveBtn.UseVisualStyleBackColor = false;
            SaveBtn.Click += SaveBtn_Click;
            // 
            // ProdDate
            // 
            ProdDate.CalendarForeColor = Color.Red;
            ProdDate.CalendarTrailingForeColor = Color.Red;
            ProdDate.Font = new Font("Arial Rounded MT Bold", 12F, FontStyle.Italic, GraphicsUnit.Point, 0);
            ProdDate.Location = new Point(1529, 216);
            ProdDate.Name = "ProdDate";
            ProdDate.RightToLeft = RightToLeft.Yes;
            ProdDate.RightToLeftLayout = true;
            ProdDate.Size = new Size(242, 31);
            ProdDate.TabIndex = 22;
            // 
            // CatCb
            // 
            CatCb.AllowDrop = true;
            CatCb.AutoCompleteCustomSource.AddRange(new string[] { "Category" });
            CatCb.FormattingEnabled = true;
            CatCb.Items.AddRange(new object[] { "Select Category" });
            CatCb.Location = new Point(274, 215);
            CatCb.Name = "CatCb";
            CatCb.Size = new Size(173, 31);
            CatCb.TabIndex = 21;
            CatCb.SelectedIndexChanged += CatCb_SelectedIndexChanged;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Arial Unicode MS", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.FromArgb(0, 192, 0);
            label8.Location = new Point(1529, 163);
            label8.Name = "label8";
            label8.Size = new Size(273, 40);
            label8.TabIndex = 20;
            label8.Text = "Item Add On Date";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Arial Unicode MS", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.FromArgb(0, 192, 0);
            label7.Location = new Point(1303, 163);
            label7.Name = "label7";
            label7.Size = new Size(188, 40);
            label7.TabIndex = 19;
            label7.Text = "Item Details";
            // 
            // ProdDetailsTb
            // 
            ProdDetailsTb.Font = new Font("Arial Unicode MS", 13.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            ProdDetailsTb.ForeColor = Color.Red;
            ProdDetailsTb.Location = new Point(1303, 206);
            ProdDetailsTb.MaxLength = 50;
            ProdDetailsTb.Multiline = true;
            ProdDetailsTb.Name = "ProdDetailsTb";
            ProdDetailsTb.PlaceholderText = "Enter  Details";
            ProdDetailsTb.Size = new Size(220, 49);
            ProdDetailsTb.TabIndex = 18;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Arial Unicode MS", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.FromArgb(0, 192, 0);
            label6.Location = new Point(1062, 163);
            label6.Name = "label6";
            label6.Size = new Size(192, 40);
            label6.TabIndex = 17;
            label6.Text = "Item S.Price";
            // 
            // SPriceTb
            // 
            SPriceTb.Font = new Font("Arial Unicode MS", 13.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            SPriceTb.ForeColor = Color.Red;
            SPriceTb.Location = new Point(1062, 206);
            SPriceTb.MaxLength = 1000;
            SPriceTb.Multiline = true;
            SPriceTb.Name = "SPriceTb";
            SPriceTb.PlaceholderText = "Enter  Sales Price";
            SPriceTb.Size = new Size(196, 49);
            SPriceTb.TabIndex = 16;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Arial Unicode MS", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.FromArgb(0, 192, 0);
            label5.Location = new Point(819, 163);
            label5.Name = "label5";
            label5.Size = new Size(192, 40);
            label5.TabIndex = 15;
            label5.Text = "Item B.Price";
            label5.Click += label5_Click;
            // 
            // BPriceTb
            // 
            BPriceTb.Font = new Font("Arial Unicode MS", 13.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            BPriceTb.ForeColor = Color.Red;
            BPriceTb.Location = new Point(819, 206);
            BPriceTb.MaxLength = 1000;
            BPriceTb.Multiline = true;
            BPriceTb.Name = "BPriceTb";
            BPriceTb.PlaceholderText = "Enter  Box Price";
            BPriceTb.Size = new Size(196, 49);
            BPriceTb.TabIndex = 14;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Arial Unicode MS", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.FromArgb(0, 192, 0);
            label4.Location = new Point(558, 163);
            label4.Name = "label4";
            label4.Size = new Size(208, 40);
            label4.TabIndex = 13;
            label4.Text = "Item Quantity";
            // 
            // QuantityTb
            // 
            QuantityTb.Font = new Font("Arial Unicode MS", 13.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            QuantityTb.ForeColor = Color.Red;
            QuantityTb.Location = new Point(558, 206);
            QuantityTb.MaxLength = 1000;
            QuantityTb.Multiline = true;
            QuantityTb.Name = "QuantityTb";
            QuantityTb.PlaceholderText = "Enter  Quantity";
            QuantityTb.Size = new Size(196, 49);
            QuantityTb.TabIndex = 12;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial Unicode MS", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.FromArgb(0, 192, 0);
            label3.Location = new Point(274, 163);
            label3.Name = "label3";
            label3.Size = new Size(219, 40);
            label3.TabIndex = 11;
            label3.Text = "Item Category";
            // 
            // ProdNameTb
            // 
            ProdNameTb.Font = new Font("Arial Unicode MS", 13.8F, FontStyle.Italic, GraphicsUnit.Point, 0);
            ProdNameTb.ForeColor = Color.Red;
            ProdNameTb.Location = new Point(44, 206);
            ProdNameTb.MaxLength = 20;
            ProdNameTb.Multiline = true;
            ProdNameTb.Name = "ProdNameTb";
            ProdNameTb.PlaceholderText = "Enter  Item Name";
            ProdNameTb.Size = new Size(196, 49);
            ProdNameTb.TabIndex = 10;
            ProdNameTb.TextChanged += ProdNameTb_TextChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial Unicode MS", 18F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.FromArgb(0, 192, 0);
            label2.Location = new Point(44, 163);
            label2.Name = "label2";
            label2.Size = new Size(173, 40);
            label2.TabIndex = 9;
            label2.Text = "Item Name";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial Rounded MT Bold", 22.2F, FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.Red;
            label1.Location = new Point(123, 46);
            label1.Name = "label1";
            label1.Size = new Size(270, 43);
            label1.TabIndex = 4;
            label1.Text = "Manage Items";
            // 
            // pictureBox9
            // 
            pictureBox9.Image = (Image)resources.GetObject("pictureBox9.Image");
            pictureBox9.Location = new Point(1749, 12);
            pictureBox9.Name = "pictureBox9";
            pictureBox9.Size = new Size(53, 58);
            pictureBox9.TabIndex = 2;
            pictureBox9.TabStop = false;
            pictureBox9.Click += pictureBox9_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(44, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(73, 77);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(3, 13);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(53, 58);
            pictureBox2.TabIndex = 1;
            pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(3, 164);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(53, 58);
            pictureBox3.TabIndex = 2;
            pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(3, 264);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(53, 58);
            pictureBox4.TabIndex = 2;
            pictureBox4.TabStop = false;
            pictureBox4.Click += pictureBox4_Click;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(2, 354);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(53, 58);
            pictureBox5.TabIndex = 2;
            pictureBox5.TabStop = false;
            pictureBox5.Click += pictureBox5_Click;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = (Image)resources.GetObject("pictureBox6.Image");
            pictureBox6.Location = new Point(3, 446);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(53, 58);
            pictureBox6.TabIndex = 2;
            pictureBox6.TabStop = false;
            pictureBox6.Click += pictureBox6_Click;
            // 
            // pictureBox7
            // 
            pictureBox7.Image = (Image)resources.GetObject("pictureBox7.Image");
            pictureBox7.Location = new Point(3, 540);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(53, 58);
            pictureBox7.TabIndex = 2;
            pictureBox7.TabStop = false;
            pictureBox7.Click += pictureBox7_Click;
            // 
            // pictureBox8
            // 
            pictureBox8.Image = (Image)resources.GetObject("pictureBox8.Image");
            pictureBox8.Location = new Point(3, 894);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(53, 58);
            pictureBox8.TabIndex = 2;
            pictureBox8.TabStop = false;
            pictureBox8.Click += pictureBox8_Click;
            // 
            // pictureBox13
            // 
            pictureBox13.Image = (Image)resources.GetObject("pictureBox13.Image");
            pictureBox13.Location = new Point(2, 739);
            pictureBox13.Name = "pictureBox13";
            pictureBox13.Size = new Size(62, 64);
            pictureBox13.TabIndex = 59;
            pictureBox13.TabStop = false;
            pictureBox13.Click += pictureBox13_Click;
            // 
            // pictureBox14
            // 
            pictureBox14.Image = (Image)resources.GetObject("pictureBox14.Image");
            pictureBox14.Location = new Point(1, 647);
            pictureBox14.Name = "pictureBox14";
            pictureBox14.Size = new Size(53, 58);
            pictureBox14.TabIndex = 60;
            pictureBox14.TabStop = false;
            pictureBox14.Click += pictureBox14_Click;
            // 
            // Items
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(0, 192, 0);
            ClientSize = new Size(1901, 983);
            Controls.Add(pictureBox14);
            Controls.Add(pictureBox13);
            Controls.Add(pictureBox8);
            Controls.Add(pictureBox7);
            Controls.Add(pictureBox6);
            Controls.Add(pictureBox5);
            Controls.Add(pictureBox4);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox2);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Items";
            Text = "Form1";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox10).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox11).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox12).EndInit();
            ((System.ComponentModel.ISupportInitialize)RefreshImg).EndInit();
            ((System.ComponentModel.ISupportInitialize)SearchImg).EndInit();
            ((System.ComponentModel.ISupportInitialize)ProductGDV).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox13).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox14).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private PictureBox pictureBox9;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
        private PictureBox pictureBox4;
        private PictureBox pictureBox5;
        private PictureBox pictureBox6;
        private PictureBox pictureBox7;
        private PictureBox pictureBox8;
        private Label label1;
        private TextBox ProdNameTb;
        private Label label2;
        private TextBox ProdDetailsTb;
        private Label label6;
        private TextBox SPriceTb;
        private Label label5;
        private TextBox BPriceTb;
        private Label label4;
        private TextBox QuantityTb;
        private Label label3;
        private ComboBox CatCb;
        private Label label8;
        private Label label7;
        private DateTimePicker ProdDate;
        private Button DeleteBtn;
        private Button EditBtn;
        private Button SaveBtn;
        private Label label9;
        private DataGridView ProductGDV;
        private TextBox SearchTb;
        private PictureBox RefreshImg;
        private PictureBox SearchImg;
        private PictureBox pictureBox10;
        private PictureBox pictureBox11;
        private PictureBox pictureBox12;
        private PictureBox pictureBox13;
        private PictureBox pictureBox14;
    }
}
